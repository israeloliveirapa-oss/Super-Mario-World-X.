#pragma once
#ifdef __cplusplus
extern "C" {
#endif
void Xbox_Menu_Init(void);
void Xbox_Menu_Shutdown(void);
void Xbox_Menu_Update(void);
void Xbox_Menu_Draw(void);
bool Xbox_Menu_IsOpen(void);
bool Xbox_Menu_IsTurbo(void);
bool Xbox_Menu_IsPaused(void);
bool Xbox_Menu_JustClosed(void);
bool Xbox_Menu_ExitRequested(void);
bool Xbox_Menu_HasToast(void);
#ifdef __cplusplus
}
#endif