/*==========================================================================
  xbox_input.cpp - Gamepad input for SMW Original Xbox port

  SNES -> Xbox mapping (by physical position):
    SNES B (bottom) jump       -> Xbox A  (green,  bottom) ab[0]
    SNES A (right)  spin jump  -> Xbox B  (red,    right)  ab[1]
    SNES Y (left)   run/hold   -> Xbox X  (blue,   left)   ab[2]
    SNES X (top)    accel      -> Xbox Y  (yellow, top)    ab[3]
    SNES L                     -> Xbox LT                  ab[6]
    SNES R                     -> Xbox RT                  ab[7]
    (White/Black unassigned - spare for future use)
    SNES Select                -> Xbox Back   wButtons 0x0020
    SNES Start                 -> Xbox Start  wButtons 0x0010
    Left Thumb click           -> Open menu   wButtons 0x0040
    D-Pad                      -> D-Pad

  input1_currentState bit layout (from SNES auto-joypad + SwapInputBits):
    bit0=B  bit1=Y  bit2=Sel  bit3=Start
    bit4=Up bit5=Dn bit6=Lt   bit7=Rt
    bit8=A  bit9=X  bit10=L   bit11=R
==========================================================================*/
#include "xbox_platform.h"

#define SMW_B (1 << 0)
#define SMW_Y (1 << 1)
#define SMW_SELECT (1 << 2)
#define SMW_START (1 << 3)
#define SMW_UP (1 << 4)
#define SMW_DOWN (1 << 5)
#define SMW_LEFT (1 << 6)
#define SMW_RIGHT (1 << 7)
#define SMW_A (1 << 8)
#define SMW_X (1 << 9)
#define SMW_L (1 << 10)
#define SMW_R (1 << 11)

#define THRESH 40
#define NUM_PORTS 4

static HANDLE s_pads[NUM_PORTS];
static uint16_t s_joypad[2];
static bool s_suppress = false; /* zero input until all buttons released */

extern "C" void Xbox_Input_Init(void) {
  ZeroMemory(s_pads, sizeof(s_pads));
  ZeroMemory(s_joypad, sizeof(s_joypad));
  XDEVICE_PREALLOC_TYPE prealloc[] = {{XDEVICE_TYPE_GAMEPAD, NUM_PORTS}};
  XInitDevices(1, prealloc);
  Sleep(50);
  DWORD ins, rem;
  XGetDeviceChanges(XDEVICE_TYPE_GAMEPAD, &ins, &rem);
  for (DWORD i = 0; i < NUM_PORTS; i++)
    if (ins & (1 << i))
      s_pads[i] = XInputOpen(XDEVICE_TYPE_GAMEPAD, i, XDEVICE_NO_SLOT, NULL);
}

extern "C" void Xbox_Input_Shutdown(void) {
  for (int i = 0; i < NUM_PORTS; i++)
    if (s_pads[i]) {
      XInputClose(s_pads[i]);
      s_pads[i] = NULL;
    }
}

extern "C" void Xbox_Input_Poll(void) {
  DWORD ins, rem;
  if (XGetDeviceChanges(XDEVICE_TYPE_GAMEPAD, &ins, &rem)) {
    for (DWORD i = 0; i < NUM_PORTS; i++) {
      if (rem & (1 << i)) {
        XInputClose(s_pads[i]);
        s_pads[i] = NULL;
      }
      if (ins & (1 << i))
        s_pads[i] = XInputOpen(XDEVICE_TYPE_GAMEPAD, i, XDEVICE_NO_SLOT, NULL);
    }
  }

  s_joypad[0] = s_joypad[1] = 0;
  int player = 0;

  for (DWORD port = 0; port < NUM_PORTS && player < 2; port++) {
    if (!s_pads[port])
      continue;
    XINPUT_STATE st;
    ZeroMemory(&st, sizeof(st));
    if (XInputGetState(s_pads[port], &st) != ERROR_SUCCESS)
      continue;

    WORD b = st.Gamepad.wButtons;
    BYTE *ab = st.Gamepad.bAnalogButtons;
    uint16_t joy = 0;

    /* D-Pad */
    if (b & XINPUT_GAMEPAD_DPAD_UP)
      joy |= SMW_UP;
    if (b & XINPUT_GAMEPAD_DPAD_DOWN)
      joy |= SMW_DOWN;
    if (b & XINPUT_GAMEPAD_DPAD_LEFT)
      joy |= SMW_LEFT;
    if (b & XINPUT_GAMEPAD_DPAD_RIGHT)
      joy |= SMW_RIGHT;

    /* Start / Back */
    if (b & XINPUT_GAMEPAD_START)
      joy |= SMW_START;
    if (b & XINPUT_GAMEPAD_BACK)
      joy |= SMW_SELECT;

    /* Face buttons */
    if (ab[XINPUT_GAMEPAD_A] > THRESH)
      joy |= SMW_B;
    if (ab[XINPUT_GAMEPAD_B] > THRESH)
      joy |= SMW_A;
    if (ab[XINPUT_GAMEPAD_X] > THRESH)
      joy |= SMW_Y;
    if (ab[XINPUT_GAMEPAD_Y] > THRESH)
      joy |= SMW_X;

    /* Shoulders */
    if (ab[XINPUT_GAMEPAD_LEFT_TRIGGER] > THRESH)
      joy |= SMW_L;
    if (ab[XINPUT_GAMEPAD_RIGHT_TRIGGER] > THRESH)
      joy |= SMW_R;
    /* White and Black buttons intentionally unassigned - spares for future use */
    /* ab[XINPUT_GAMEPAD_WHITE] - unassigned */
    /* ab[XINPUT_GAMEPAD_BLACK] - unassigned */

    /* If suppressing, zero input until controller fully released */
    if (s_suppress) {
      if (joy == 0)
        s_suppress = false;
      else
        joy = 0;
    }
    s_joypad[player++] = joy;
  }
}

extern "C" void Xbox_Input_SuppressUntilRelease(void) {
  s_suppress = true;
}

extern "C" uint16_t Xbox_Input_GetJoypad(int player) {
  return (player >= 0 && player < 2) ? s_joypad[player] : 0;
}


extern "C" XINPUT_STATE Xbox_Input_GetRawState(void) {
  XINPUT_STATE st;
  ZeroMemory(&st, sizeof(st));
  for (int i = 0; i < NUM_PORTS; i++)
    if (s_pads[i] && XInputGetState(s_pads[i], &st) == ERROR_SUCCESS)
      break;
  return st;
}