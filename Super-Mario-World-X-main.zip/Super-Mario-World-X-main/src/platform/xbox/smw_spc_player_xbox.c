/*
 * smw_spc_player_xbox.c - Xbox wrapper for smw_spc_player.c
 *
 * smw_spc_player.c calls dsp_getSamples() with 3 args but dsp.h now
 * declares it with 4 args (numChannels added). Fix via macro AFTER the
 * header is included so the declaration isn't affected.
 */

/* Include dsp.h first so its 4-arg declaration is seen cleanly */
#include "snes/dsp.h"

/* Now redirect 3-arg calls to 4-arg - only affects call sites below */
#define dsp_getSamples(dsp, buf, frames) dsp_getSamples(dsp, buf, frames, 2)

/* Include the original unmodified file */
#include "../../smw_spc_player.c"