/*==========================================================================
  xbox_menu.cpp - In-game overlay menu for SMW Xbox port
  Open/Close: L3 (left thumbstick click)
  Navigate: DPad up/down, A=select, B=back
  Based directly on zelda3 xbox_menu.cpp - same font, same draw helpers.
==========================================================================*/
#include "xbox_menu.h"

#include "xbox_platform.h"

extern "C" {
void Xbox_ApplyRenderFlags(void);
#include "../../common_rtl.h"
#include "../../config.h"
#include "../../smw_rtl.h"
extern void Xbox_Config_Save(void);
extern void Xbox_Config_Load(void);
extern void Xbox_SaveState(int slot);
extern void Xbox_LoadState(int slot);
extern const char* Xbox_GetStateDir(int slot0based);
extern void Xbox_D3D_SetDispMode(int v);
extern int Xbox_D3D_GetDispMode(void);
extern int Xbox_D3D_GetDispW(void);
extern int Xbox_D3D_GetDispH(void);
extern bool s_has_smb1;
extern bool s_has_smbll;
extern int s_selected_game;
extern void Xbox_RestartWithGame(int game);
extern uint8 g_ram[];
extern void GiveOneCoin(void);
extern void Smbll_GiveOneCoin(void);
}

/*==========================================================================
  8x8 bitmap font - verbatim from zelda3 xbox_menu.cpp
==========================================================================*/
static const BYTE kFont8x8[][8] = {
    {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00}, {0x18, 0x18, 0x18, 0x18, 0x18, 0x00, 0x18, 0x00},
    {0x66, 0x66, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00}, {0x66, 0x66, 0xFF, 0x66, 0xFF, 0x66, 0x66, 0x00},
    {0x18, 0x3E, 0x60, 0x3C, 0x06, 0x7C, 0x18, 0x00}, {0x62, 0x66, 0x0C, 0x18, 0x30, 0x66, 0x46, 0x00},
    {0x3C, 0x66, 0x3C, 0x38, 0x67, 0x66, 0x3F, 0x00}, {0x18, 0x18, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},
    {0x0C, 0x18, 0x30, 0x30, 0x30, 0x18, 0x0C, 0x00}, {0x30, 0x18, 0x0C, 0x0C, 0x0C, 0x18, 0x30, 0x00},
    {0x00, 0x66, 0x3C, 0xFF, 0x3C, 0x66, 0x00, 0x00}, {0x00, 0x18, 0x18, 0x7E, 0x18, 0x18, 0x00, 0x00},
    {0x00, 0x00, 0x00, 0x00, 0x00, 0x18, 0x18, 0x30}, {0x00, 0x00, 0x00, 0x7E, 0x00, 0x00, 0x00, 0x00},
    {0x00, 0x00, 0x00, 0x00, 0x00, 0x18, 0x18, 0x00}, {0x03, 0x06, 0x0C, 0x18, 0x30, 0x60, 0x40, 0x00},
    {0x3C, 0x66, 0x6E, 0x76, 0x66, 0x66, 0x3C, 0x00}, {0x18, 0x38, 0x18, 0x18, 0x18, 0x18, 0x7E, 0x00},
    {0x3C, 0x66, 0x06, 0x0C, 0x18, 0x30, 0x7E, 0x00}, {0x3C, 0x66, 0x06, 0x1C, 0x06, 0x66, 0x3C, 0x00},
    {0x0C, 0x1C, 0x3C, 0x6C, 0x7E, 0x0C, 0x0C, 0x00}, {0x7E, 0x60, 0x7C, 0x06, 0x06, 0x66, 0x3C, 0x00},
    {0x1C, 0x30, 0x60, 0x7C, 0x66, 0x66, 0x3C, 0x00}, {0x7E, 0x06, 0x0C, 0x18, 0x30, 0x30, 0x30, 0x00},
    {0x3C, 0x66, 0x66, 0x3C, 0x66, 0x66, 0x3C, 0x00}, {0x3C, 0x66, 0x66, 0x3E, 0x06, 0x0C, 0x38, 0x00},
    {0x00, 0x18, 0x18, 0x00, 0x00, 0x18, 0x18, 0x00}, {0x00, 0x18, 0x18, 0x00, 0x00, 0x18, 0x18, 0x30},
    {0x0C, 0x18, 0x30, 0x60, 0x30, 0x18, 0x0C, 0x00}, {0x00, 0x00, 0x7E, 0x00, 0x7E, 0x00, 0x00, 0x00},
    {0x30, 0x18, 0x0C, 0x06, 0x0C, 0x18, 0x30, 0x00}, {0x3C, 0x66, 0x06, 0x0C, 0x18, 0x00, 0x18, 0x00},
    {0x3C, 0x66, 0x6E, 0x6E, 0x60, 0x62, 0x3C, 0x00}, {0x18, 0x3C, 0x66, 0x7E, 0x66, 0x66, 0x66, 0x00},
    {0x7C, 0x66, 0x66, 0x7C, 0x66, 0x66, 0x7C, 0x00}, {0x3C, 0x66, 0x60, 0x60, 0x60, 0x66, 0x3C, 0x00},
    {0x78, 0x6C, 0x66, 0x66, 0x66, 0x6C, 0x78, 0x00}, {0x7E, 0x60, 0x60, 0x7C, 0x60, 0x60, 0x7E, 0x00},
    {0x7E, 0x60, 0x60, 0x7C, 0x60, 0x60, 0x60, 0x00}, {0x3C, 0x66, 0x60, 0x6E, 0x66, 0x66, 0x3C, 0x00},
    {0x66, 0x66, 0x66, 0x7E, 0x66, 0x66, 0x66, 0x00}, {0x3C, 0x18, 0x18, 0x18, 0x18, 0x18, 0x3C, 0x00},
    {0x1E, 0x0C, 0x0C, 0x0C, 0x0C, 0x6C, 0x38, 0x00}, {0x66, 0x6C, 0x78, 0x70, 0x78, 0x6C, 0x66, 0x00},
    {0x60, 0x60, 0x60, 0x60, 0x60, 0x60, 0x7E, 0x00}, {0x63, 0x77, 0x7F, 0x6B, 0x63, 0x63, 0x63, 0x00},
    {0x66, 0x76, 0x7E, 0x7E, 0x6E, 0x66, 0x66, 0x00}, {0x3C, 0x66, 0x66, 0x66, 0x66, 0x66, 0x3C, 0x00},
    {0x7C, 0x66, 0x66, 0x7C, 0x60, 0x60, 0x60, 0x00}, {0x3C, 0x66, 0x66, 0x66, 0x6E, 0x3C, 0x06, 0x00},
    {0x7C, 0x66, 0x66, 0x7C, 0x6C, 0x66, 0x66, 0x00}, {0x3C, 0x66, 0x60, 0x3C, 0x06, 0x66, 0x3C, 0x00},
    {0x7E, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x00}, {0x66, 0x66, 0x66, 0x66, 0x66, 0x66, 0x3C, 0x00},
    {0x66, 0x66, 0x66, 0x66, 0x66, 0x3C, 0x18, 0x00}, {0x63, 0x63, 0x63, 0x6B, 0x7F, 0x77, 0x63, 0x00},
    {0x66, 0x66, 0x3C, 0x18, 0x3C, 0x66, 0x66, 0x00}, {0x66, 0x66, 0x66, 0x3C, 0x18, 0x18, 0x18, 0x00},
    {0x7E, 0x06, 0x0C, 0x18, 0x30, 0x60, 0x7E, 0x00}, {0x3C, 0x30, 0x30, 0x30, 0x30, 0x30, 0x3C, 0x00},
    {0x60, 0x30, 0x18, 0x0C, 0x06, 0x03, 0x01, 0x00}, {0x3C, 0x0C, 0x0C, 0x0C, 0x0C, 0x0C, 0x3C, 0x00},
    {0x18, 0x3C, 0x66, 0x00, 0x00, 0x00, 0x00, 0x00}, {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xFF},
};

extern LPDIRECT3DDEVICE8 g_pDevice;
struct MenuVert {
  float x, y, z, rhw;
  DWORD color;
};
#define FVF_MENU (D3DFVF_XYZRHW | D3DFVF_DIFFUSE)

static void DrawRect(float x, float y, float w, float h, DWORD color) {
  MenuVert v[4] = {{x, y, 0, 1, color}, {x + w, y, 0, 1, color}, {x, y + h, 0, 1, color}, {x + w, y + h, 0, 1, color}};
  g_pDevice->SetVertexShader(FVF_MENU);
  g_pDevice->SetTexture(0, NULL);
  g_pDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
  g_pDevice->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
  g_pDevice->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);
  g_pDevice->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 2, v, sizeof(MenuVert));
  g_pDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
}
static void DrawChar(float x, float y, char c, DWORD color, float sc) {
  if (c < 32 || c > 127)
    c = 32;
  const BYTE* g = kFont8x8[(unsigned char)c - 32];
  for (int r = 0; r < 8; r++) {
    BYTE b = g[r];
    for (int col = 0; col < 8; col++)
      if (b & (0x80 >> col))
        DrawRect(x + col * sc, y + r * sc, sc, sc, color);
  }
}
static void DrawString(float x, float y, const char* s, DWORD color, float sc) {
  for (; *s; s++, x += 8 * sc) {
    char c = *s;
    if (c >= 'a' && c <= 'z')
      c -= 32;
    DrawChar(x, y, c, color, sc);
  }
}
static void DrawMenu(float cx, float cy, const char* title, const char** items, int count, int sel, float sc) {
  float CW = 8 * sc, CH = 8 * sc, PAD = 8.0f, ROW = CH + 4.0f;
  int maxLen = (int)strlen(title);
  for (int i = 0; i < count; i++) {
    int l = (int)strlen(items[i]) + 2;
    if (l > maxLen)
      maxLen = l;
  }
  float mw = maxLen * CW + PAD * 2 + 4;
  float mh = PAD * 2 + (count + 1) * ROW + 4;
  float mx = cx - mw / 2, my = cy - mh / 2;
  DrawRect(mx - 2, my - 2, mw + 4, mh + 4, 0xFF00AAFF);
  DrawRect(mx, my, mw, mh, 0xE0001020);
  /* Centre title in box */
  float titleX = mx + (mw - strlen(title) * CW) * 0.5f;
  DrawString(titleX, my + PAD, title, 0xFFFFFF00, sc);
  float y = my + PAD + ROW;
  for (int i = 0; i < count; i++) {
    DWORD col = (i == sel) ? 0xFF00FF00 : 0xFFCCCCCC;
    /* Centre item text - account for "> " prefix width */
    int itemLen = (int)strlen(items[i]);
    float itemX = mx + (mw - (itemLen + 2) * CW) * 0.5f;
    if (i == sel)
      DrawString(itemX, y, ">", col, sc);
    DrawString(itemX + CW * 2, y, items[i], col, sc);
    y += ROW;
  }
}

/*==========================================================================
  Pages
==========================================================================*/
enum MenuPage { PAGE_MAIN = 0, PAGE_CHEATS, PAGE_SETTINGS_GFX, PAGE_SETTINGS_GAME, PAGE_SAVE, PAGE_LOAD, PAGE_GAME_SELECT, PAGE_COUNT };

/*==========================================================================
  State
==========================================================================*/
static bool s_open = false;
static bool s_turbo = false;
static bool s_paused = false;
static bool s_justClosed = false;
static bool s_exit_requested = false;
extern "C" bool Xbox_Menu_ExitRequested(void) { return s_exit_requested; }
static void Xbox_Menu_RequestExit(void) { s_exit_requested = true; }
static MenuPage s_page = PAGE_MAIN;
static int s_sel[PAGE_COUNT] = {0};
static int s_pendingDispMode = -1;

/* Toast notification - shown briefly after save/load/cheat */
static char s_toast_msg[64] = "";
static int s_toast_timer = 0;
#define TOAST_FRAMES 60

static void ShowToast(const char* msg) {
  _snprintf(s_toast_msg, sizeof(s_toast_msg), "%s", msg);
  s_toast_timer = TOAST_FRAMES;
}

/* Called from main loop each game frame to draw toast over gameplay */
extern "C" bool Xbox_Menu_HasToast(void) {
  return s_toast_timer > 0;
}
/*==========================================================================
  Menu item arrays
==========================================================================*/
static const char* kMain[] = {"CHEATS",     "SETTINGS",   "SAVE STATE",  "LOAD STATE", "TURBO MODE",
                              "PAUSE GAME", "RESET GAME", "SWITCH GAME", "EXIT GAME",  "CLOSE"};
static const int kMainN = 10;

static const char* kCheats[] = {"ADD LIFE",   "ITEM: MUSHROOM", "ITEM: FIRE FLOWER", "ITEM: STAR",
                                "ITEM: CAPE", "ADD 50 COINS",   "FULL TIME",         "BACK"};
static const int kCheatsN = 8;

/* SMB1 / SMBLL cheats (same RAM addresses for both) */
static const char* kCheatsRom[] = {"ADD LIFE", "SUPER MARIO", "FIRE MARIO", "STAR POWER", "ADD 50 COINS", "FULL TIME", "BACK"};
static const int kCheatsRomN = 7;

static const char* kSlots[] = {"SLOT 1", "SLOT 2", "SLOT 3", "SLOT 4", "SLOT 5", "SLOT 6", "SLOT 7", "SLOT 8", "SLOT 9", "SLOT 10"};

/*==========================================================================
  Input helpers - same as Zelda3
==========================================================================*/
extern "C" XINPUT_STATE Xbox_Input_GetRawState(void);
extern "C" void Xbox_Input_SuppressUntilRelease(void);
static bool BtnPressed(DWORD cur, DWORD prev, DWORD mask) {
  return (cur & mask) && !(prev & mask);
}

/*==========================================================================
  Public API
==========================================================================*/
extern "C" {
void Xbox_Menu_Init(void) {
  s_open = false;
  s_page = PAGE_MAIN;
  for (int i = 0; i < PAGE_COUNT; i++)
    s_sel[i] = 0;
}
void Xbox_Menu_Shutdown(void) {
}
bool Xbox_Menu_IsOpen(void) {
  return s_open;
}
bool Xbox_Menu_IsTurbo(void) {
  return s_turbo;
}
bool Xbox_Menu_IsPaused(void) {
  return s_paused;
}
bool Xbox_Menu_JustClosed(void) {
  bool v = s_justClosed;
  s_justClosed = false;
  return v;
}
}

/*==========================================================================
  Update
==========================================================================*/
extern "C" void Xbox_Menu_Update(void) {
  XINPUT_STATE st = Xbox_Input_GetRawState();
  DWORD cur = st.Gamepad.wButtons;
  BYTE* ab = st.Gamepad.bAnalogButtons;

  static DWORD prev = 0;

  /* L3 toggles menu */
  if (BtnPressed(cur, prev, XINPUT_GAMEPAD_LEFT_THUMB)) {
    s_open = !s_open;
    if (s_open) {
      s_page = PAGE_MAIN;
      for (int i = 0; i < PAGE_COUNT; i++)
        s_sel[i] = 0;
      s_pendingDispMode = -1;
    }
  }

  if (!s_open) {
    prev = cur;
    return;
  }

  int count = 0;
  switch (s_page) {
  case PAGE_MAIN: count = kMainN; break;
  case PAGE_CHEATS: count = (s_selected_game != 0) ? kCheatsRomN : kCheatsN; break;
  case PAGE_SETTINGS_GFX: count = 3; break;
  case PAGE_SETTINGS_GAME: count = 5; break;
  case PAGE_SAVE:
  case PAGE_LOAD: count = 10; break;
  case PAGE_GAME_SELECT: count = 1 + (s_has_smb1 ? 1 : 0) + (s_has_smbll ? 1 : 0) + 1; break;
  default: break;
  }

  int* sel = &s_sel[(int)s_page];

  if (BtnPressed(cur, prev, XINPUT_GAMEPAD_DPAD_UP))
    *sel = (*sel - 1 + count) % count;
  if (BtnPressed(cur, prev, XINPUT_GAMEPAD_DPAD_DOWN))
    *sel = (*sel + 1) % count;

  /* B button or Back button = go back/close menu */
  bool bBtn = ab[XINPUT_GAMEPAD_B] > 128;
  bool bPrev = (prev & 0x10000) != 0;
  bool backPressed = BtnPressed(cur, prev, XINPUT_GAMEPAD_BACK);
  if ((bBtn && !bPrev) || backPressed) {
    if (s_page == PAGE_MAIN) {
      if (s_pendingDispMode >= 0 && s_pendingDispMode != Xbox_D3D_GetDispMode()) {
        Xbox_D3D_SetDispMode(s_pendingDispMode);
        Xbox_Config_Save();
      }
      s_pendingDispMode = -1;
      s_open = false;
      s_justClosed = true;
      Xbox_Input_SuppressUntilRelease();
    } else {
      s_page = PAGE_MAIN;
    }
  }

  /* A = select */
  bool aBtn = ab[XINPUT_GAMEPAD_A] > 128;
  bool aPrev = (prev & 0x20000) != 0;
  if (aBtn && !aPrev) {
    bool close = false, goBack = false;
    switch (s_page) {
    case PAGE_MAIN:
      switch (*sel) {
      case 0: s_page = PAGE_CHEATS; break;
      case 1: s_page = PAGE_SETTINGS_GFX; break;
      case 2: s_page = PAGE_SAVE; break;
      case 3: s_page = PAGE_LOAD; break;
      case 4:
        s_turbo = !s_turbo;
        close = true;
        break;
      case 5:
        s_paused = !s_paused;
        close = true;
        break;
      case 6:
        extern void Xbox_Reset(void);
        Xbox_Reset();
        RtlReadSram();
        Xbox_Config_Load();
        close = true;
        break;
      case 7: s_page = PAGE_GAME_SELECT; break;
      case 8: Xbox_Menu_RequestExit(); close = true; break;
      case 9: close = true; break;
      }
      break;

    case PAGE_GAME_SELECT: {
      /* Build the same ordered list as draw so positions always match */
      int gameIds[4]; int gameCount = 0;
      gameIds[gameCount++] = 0; /* SMW always present */
      if (s_has_smb1)  gameIds[gameCount++] = 1;
      if (s_has_smbll) gameIds[gameCount++] = 2;
      gameIds[gameCount++] = -1; /* BACK */
      if (*sel >= 0 && *sel < gameCount) {
        int chosen = gameIds[*sel];
        if (chosen == -1) { goBack = true; }
        else { Xbox_RestartWithGame(chosen); goBack = true; }
      }
      break;
    }

    case PAGE_CHEATS:
      if (s_selected_game != 0) {
        /* SMB1 / SMBLL cheats */
        switch (*sel) {
        case 0: /* ADD LIFE */
          if (g_ram[0x75A] < 99)
            g_ram[0x75A]++;
          ShowToast("LIFE ADDED");
          close = true;
          break;
        case 1: /* SUPER MARIO */
          ShowToast("SUPER MARIO!");
          g_ram[0x1600] = 10; /* sound_ch1 = powerup sound */
          /* player_size: 0=large, 1=small. Animation toggles size. */
          g_ram[0x756] = 1;   /* player_status=1 (super) */
          g_ram[0x754] = 1;   /* player_size=1 (small, animation will toggle to 0=large) */
          g_ram[0x70B] = 0;   /* player_change_size_flag=0 */
          g_ram[0x0F] = 9;    /* game_engine_subroutine=PlayerChangeSize */
          g_ram[0x28] = 0;    /* player_state=0 */
          g_ram[0x747] = 255; /* timer_control=-1 */
          g_ram[0x775] = 0;   /* scroll_amount=0 */
          close = true;
          break;
        case 2: /* FIRE MARIO */
          ShowToast("FIRE MARIO!");
          g_ram[0x1600] = 10; /* sound_ch1 = powerup sound */
          /* Already large (size=0), just change palette and status */
          g_ram[0x756] = 2;   /* player_status=2 (fire) */
          g_ram[0x754] = 0;   /* player_size=0 (large) */
          g_ram[0x0F] = 12;   /* game_engine_subroutine=PlayerFireFlower */
          g_ram[0x28] = 0;    /* player_state=0 */
          g_ram[0x747] = 255; /* timer_control=-1 */
          g_ram[0x775] = 0;   /* scroll_amount=0 */
          close = true;
          break;
        case 3: /* STAR POWER */
          ShowToast("STAR POWER!");
          g_ram[0x7AF] = 35;  /* player_star_power_timer */
          g_ram[0x1602] = 13; /* music_ch1: star music */
          close = true;
          break;
        case 4: /* ADD 50 COINS */
          ShowToast("50 COINS ADDED");
          for (int _i = 0; _i < 50; _i++)
            (s_selected_game == 1) ? GiveOneCoin() : Smbll_GiveOneCoin();
          close = true;
          break;
        case 5: /* FULL TIME */
          ShowToast("TIME RESTORED");
          g_ram[0x7E9] = 4; /* hundreds */
          g_ram[0x7EA] = 0; /* tens */
          g_ram[0x7EB] = 0; /* ones */
          close = true;
          break;
        case 6: /* BACK */ goBack = true; break;
        }
      } else {
        /* SMW cheats */
        switch (*sel) {
        case 0: /* ADD LIFE */
          if (g_ram[0xDBE] < 99)
            g_ram[0xDBE]++;
          ShowToast("LIFE ADDED");
          close = true;
          break;
        case 1:
          g_ram[0xDC2] = 1;
          ShowToast("MUSHROOM ADDED");
          close = true;
          break;
        case 2:
          g_ram[0xDC2] = 2;
          ShowToast("FIRE FLOWER ADDED");
          close = true;
          break;
        case 3:
          g_ram[0xDC2] = 3;
          ShowToast("STAR ADDED");
          close = true;
          break;
        case 4:
          g_ram[0xDC2] = 4;
          ShowToast("CAPE ADDED");
          close = true;
          break;
        case 5:
          g_ram[0xDBF] = (g_ram[0xDBF] + 50 > 99) ? 99 : g_ram[0xDBF] + 50;
          ShowToast("50 COINS ADDED");
          close = true;
          break;
        case 6:
          g_ram[0xF31] = 4;
          g_ram[0xF32] = 0;
          g_ram[0xF33] = 0;
          ShowToast("TIME RESTORED");
          close = true;
          break;
        case 7: goBack = true; break;
        }
      }
      break;

    case PAGE_SETTINGS_GFX: {
      switch (*sel) {
      case 0: {
        int cur2 = s_pendingDispMode >= 0 ? s_pendingDispMode : Xbox_D3D_GetDispMode();
        s_pendingDispMode = (cur2 + 1) % 2;
        break;
      }
      case 1:
        g_config.no_sprite_limits = !g_config.no_sprite_limits;
        Xbox_ApplyRenderFlags();
        Xbox_Config_Save();
        break;
      case 2: goBack = true; break;
      }
      break;
    }

    case PAGE_SETTINGS_GAME: {
      switch (*sel) {
      case 0:
        g_config.autosave = !g_config.autosave;
        Xbox_Config_Save();
        break;
      case 1:
        g_config.disable_frame_delay = !g_config.disable_frame_delay;
        Xbox_Config_Save();
        break;
      case 2:
        g_config.enable_audio = !g_config.enable_audio;
        Xbox_Config_Save();
        break;
      case 3:
        g_config.no_sprite_limits = !g_config.no_sprite_limits;
        Xbox_ApplyRenderFlags();
        Xbox_Config_Save();
        break;
      case 4: goBack = true; break;
      }
      break;
    }

    case PAGE_SAVE:
      Xbox_SaveState(*sel);
      {
        char _t[32];
        _snprintf(_t, sizeof(_t), "STATE SAVED - SLOT %d", *sel + 1);
        ShowToast(_t);
      }
      close = true;
      break;

    case PAGE_LOAD: {
      /* Check state exists before loading - Xbox_GetStateDir returns NULL if not found */
      const char* stateDir = Xbox_GetStateDir(*sel);
      if (stateDir) {
        Xbox_LoadState(*sel);
        char _t[32];
        _snprintf(_t, sizeof(_t), "STATE LOADED - SLOT %d", *sel + 1);
        ShowToast(_t);
      } else {
        ShowToast("NO SAVE IN THIS SLOT");
      }
      close = true;
      break;
    }

    default: break;
    }

    if (goBack)
      s_page = (s_page == PAGE_CHEATS || s_page == PAGE_SETTINGS_GFX || s_page == PAGE_SETTINGS_GAME || s_page == PAGE_SAVE ||
                s_page == PAGE_LOAD)
                   ? PAGE_MAIN
                   : PAGE_MAIN;
    if (close) {
      if (s_pendingDispMode >= 0 && s_pendingDispMode != Xbox_D3D_GetDispMode()) {
        Xbox_D3D_SetDispMode(s_pendingDispMode);
        Xbox_Config_Save();
      }
      s_pendingDispMode = -1;
      s_open = false;
      s_justClosed = true;
      Xbox_Input_SuppressUntilRelease();
    }
  }

  prev = cur | (bBtn ? 0x10000 : 0) | (aBtn ? 0x20000 : 0);
}

/*==========================================================================
  Draw
==========================================================================*/
extern "C" void Xbox_Menu_Draw(void) {
  if (!g_pDevice)
    return;

  const float SC = 1.0f;
  const float CX = (float)Xbox_D3D_GetDispW() / 2.0f;
  const float CY = (float)Xbox_D3D_GetDispH() / 2.0f;

  if (!s_open) {
    if (s_toast_timer > 0) {
      --s_toast_timer;
      float alpha = (s_toast_timer < 30) ? (s_toast_timer / 30.0f) : 1.0f;
      DWORD a = (DWORD)(alpha * 255.0f);
      const float tsc = 1.0f;
      const float CW = 8 * tsc, PAD = 4.0f;
      int len = (int)strlen(s_toast_msg);
      float bw = len * CW + PAD * 2 + 4;
      float bh = CW + PAD * 2 + 4;
      float bx = CX - bw * 0.5f;
      float by = CY - bh * 0.5f;
      /* Box border + background same style as menu */
      DWORD ba = (DWORD)(alpha * 0xFF);
      DrawRect(bx - 2, by - 2, bw + 4, bh + 4, (ba << 24) | 0x0000AAFF); /* border */
      DrawRect(bx, by, bw, bh, (ba << 24) | 0x00001020);                 /* background */
      /* White text centered */
      float tx = CX - (len * CW * 0.5f);
      float ty = by + PAD;
      DrawString(tx, ty, s_toast_msg, (a << 24) | 0x00FFFFFF, tsc);
    }
    return;
  }

  switch (s_page) {
  case PAGE_MAIN: {
    const char* gt = (s_selected_game == 1)   ? "SUPER MARIO BROS 1"
                     : (s_selected_game == 2) ? "SUPER MARIO BROS LOST LEVELS"
                                              : "SUPER MARIO WORLD";
    DrawMenu(CX, CY, gt, (const char**)kMain, kMainN, s_sel[PAGE_MAIN], SC);
    break;
  }

  case PAGE_CHEATS:
    if (s_selected_game != 0)
      DrawMenu(CX, CY, "CHEATS", (const char**)kCheatsRom, kCheatsRomN, s_sel[PAGE_CHEATS], SC);
    else
      DrawMenu(CX, CY, "CHEATS", (const char**)kCheats, kCheatsN, s_sel[PAGE_CHEATS], SC);
    break;

  case PAGE_SETTINGS_GFX: {
    static char sg0[32], sg1[32];
    static const char* modes[] = {"4:3", "FILL"};
    int show = s_pendingDispMode >= 0 ? s_pendingDispMode : Xbox_D3D_GetDispMode();
    _snprintf(sg0, sizeof(sg0), "DISPLAY MODE     [%s]", modes[show]);
    _snprintf(sg1, sizeof(sg1), "NO SPRITE LIMITS [%s]", g_config.no_sprite_limits ? "ON " : "OFF");
    static const char* sgItems[3];
    sgItems[0] = sg0;
    sgItems[1] = sg1;
    sgItems[2] = "BACK";
    DrawMenu(CX, CY, "SETTINGS - GRAPHICS", (const char**)sgItems, 3, s_sel[PAGE_SETTINGS_GFX], SC);
    break;
  }

  case PAGE_SETTINGS_GAME: {
    static char sp0[32], sp1[32], sp2[32], sp3[32];
    _snprintf(sp0, sizeof(sp0), "AUTOSAVE         [%s]", g_config.autosave ? "ON " : "OFF");
    _snprintf(sp1, sizeof(sp1), "DISABLE FRM DLAY [%s]", g_config.disable_frame_delay ? "ON " : "OFF");
    _snprintf(sp2, sizeof(sp2), "ENABLE AUDIO     [%s]", g_config.enable_audio ? "ON " : "OFF");
    _snprintf(sp3, sizeof(sp3), "NO SPRITE LIMITS [%s]", g_config.no_sprite_limits ? "ON " : "OFF");
    static const char* spItems[5];
    spItems[0] = sp0;
    spItems[1] = sp1;
    spItems[2] = sp2;
    spItems[3] = sp3;
    spItems[4] = "BACK";
    DrawMenu(CX, CY, "SETTINGS - GAME", (const char**)spItems, 5, s_sel[PAGE_SETTINGS_GAME], SC);
    break;
  }

  case PAGE_SAVE: DrawMenu(CX, CY, "SAVE STATE", (const char**)kSlots, 10, s_sel[PAGE_SAVE], SC); break;

  case PAGE_LOAD: DrawMenu(CX, CY, "LOAD STATE", (const char**)kSlots, 10, s_sel[PAGE_LOAD], SC); break;

  case PAGE_GAME_SELECT: {
    /* Build list dynamically so positions match action handler exactly */
    static const char* gItems[4];
    int gCount = 0;
    gItems[gCount++] = "SUPER MARIO WORLD";
    if (s_has_smb1)  gItems[gCount++] = "SUPER MARIO BROS 1";
    if (s_has_smbll) gItems[gCount++] = "SUPER MARIO BROS LL";
    gItems[gCount++] = "BACK";
    DrawMenu(CX, CY, "SWITCH GAME", (const char**)gItems, gCount, s_sel[PAGE_GAME_SELECT], SC);
    break;
  }

  default: break;
  }
}