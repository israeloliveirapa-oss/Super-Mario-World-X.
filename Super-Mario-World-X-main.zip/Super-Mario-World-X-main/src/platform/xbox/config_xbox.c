/*
 * config_xbox.c - Replaces src/config.c for Xbox build.
 * config.c unconditionally includes SDL.h for keyboard mapping.
 * On Xbox we don't need keyboard mapping - controller handled by xbox_input.cpp.
 * This stub provides g_config and the required function signatures.
 * Original config.c is UNMODIFIED and not in the Xbox build.
 */
#include "../../config.h"
#include "../../types.h"
#include <string.h>

Config g_config;

void ParseConfigFile(const char *filename) { (void)filename; }
int  FindCmdForSdlKey(int code, int mod) { (void)code; (void)mod; return 0; }
