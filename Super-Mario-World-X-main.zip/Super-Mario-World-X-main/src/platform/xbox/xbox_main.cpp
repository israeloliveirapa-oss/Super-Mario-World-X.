/*==========================================================================
  xbox_main.cpp - SMW Original Xbox port entry point
  Replaces src/main.c entirely. Original source files are unmodified.
==========================================================================*/
#include "xbox_menu.h"
#include "xbox_platform.h"

extern "C" {
#include "../../assets/smw_assets.h"
#include "../../common_cpu_infra.h"
#include "../../common_rtl.h"
#include "../../config.h"
#include "../../smw_rtl.h"
#include "../../smw_spc_player.h"
#include "../../snes/ppu.h"
#include "../../snes/snes.h"
#include "../../types.h"
#include "../../util.h"
}

/* -----------------------------------------------------------------------
   Globals that main.c normally provides
----------------------------------------------------------------------- */
const uint8 *g_asset_ptrs[kNumberOfAssets];
uint32 g_asset_sizes[kNumberOfAssets];
/* forward declaration - defined later in this file */
extern "C" const char *Xbox_GetGameTitle(void);

/* xbox_savegame.cpp - forward declarations */
extern "C" bool Xbox_Menu_ExitRequested(void);
extern "C" void Xbox_ResolveSavePaths(int game);
extern "C" const char *Xbox_GetSramDir(void);
extern "C" const char *Xbox_GetStateDir(int slot0based);
extern "C" const char *Xbox_GetStateDirCreate(int slot0based);

extern "C" bool g_other_image = true;
extern "C" bool g_new_ppu = true;
extern "C" bool g_no_sprite_limits = true; /* checked by ppu_xbox.c */
extern "C" bool g_debug_flag = false;
extern "C" int g_got_mismatch_count = 0;
extern "C" SpcPlayer *g_spc_player = NULL;
extern "C" uint32 g_wanted_features = 0;

/* Multi-game support */
extern "C" int s_selected_game = 0;
extern "C" bool s_has_smb1 = false;
extern "C" bool s_has_smbll = false;

static const char *kSmb1Paths[] = {"D:\\Media\\smb1.sfc", NULL};
static const char *kSmbllPaths[] = {"D:\\Media\\smbll.sfc", NULL};

static uint8_t *TryLoadFile(const char **paths, size_t *out_size) {
  for (int i = 0; paths[i]; i++) {
    size_t sz = 0;
    uint8_t *d = (uint8_t *)ReadWholeFile(paths[i], &sz);
    if (d) {
      *out_size = sz;
      return d;
    }
  }
  return NULL;
}

/* s_game_choice_dir always points to the SMW (game=0) UDATA container.
   smw_game.cfg must be in a fixed location readable before we know
   which game to run. SMW container is always resolved first at boot. */
static char s_game_choice_dir[MAX_PATH] = "";

static void SaveGameChoice(int game) {
  if (!s_game_choice_dir[0])
    return;
  char path[MAX_PATH];
  _snprintf(path, sizeof(path), "%ssmw_game.cfg", s_game_choice_dir);
  HANDLE f = CreateFile(path, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
  if (f != INVALID_HANDLE_VALUE) {
    DWORD w;
    WriteFile(f, &game, 4, &w, NULL);
    CloseHandle(f);
  }
}
static int LoadGameChoice(void) {
  int game = 0;
  if (!s_game_choice_dir[0])
    return 0;
  char path[MAX_PATH];
  _snprintf(path, sizeof(path), "%ssmw_game.cfg", s_game_choice_dir);
  HANDLE f = CreateFile(path, GENERIC_READ, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
  if (f != INVALID_HANDLE_VALUE) {
    DWORD r;
    ReadFile(f, &game, 4, &r, NULL);
    CloseHandle(f);
  }
  return game;
}
extern "C" void Xbox_RestartWithGame(int game) {
  SaveGameChoice(game);
  static const char *kXbePaths[] = {"D:\\default.xbe", NULL};
  for (int i = 0; kXbePaths[i]; i++) {
    HANDLE f = CreateFile(kXbePaths[i], GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, 0, NULL);
    if (f != INVALID_HANDLE_VALUE) {
      CloseHandle(f);
      XLaunchNewImage(kXbePaths[i], NULL);
    }
  }
  OutputDebugStringA("SMW: Could not relaunch - no XBE found\n");
}

/* -----------------------------------------------------------------------
   SRAM (battery save)
----------------------------------------------------------------------- */
static uint8_t s_sram_buf[0x10000]; /* 64KB - covers all SNES SRAM sizes */

extern "C" uint8_t *readSramImpl(void) {
  DWORD sz = (g_sram && g_sram_size > 0) ? (DWORD)g_sram_size : (DWORD)sizeof(s_sram_buf);
  uint8_t *dst = (g_sram && g_sram_size > 0) ? g_sram : s_sram_buf;
  memset(dst, 0, sz);
  const char *dir = Xbox_GetSramDir();
  if (dir && dir[0]) {
    char path[MAX_PATH];
    _snprintf(path, sizeof(path), "%s%s.srm", dir, Xbox_GetGameTitle());
    HANDLE f = CreateFile(path, GENERIC_READ, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (f != INVALID_HANDLE_VALUE) {
      DWORD r = 0;
      ReadFile(f, dst, sz, &r, NULL);
      CloseHandle(f);
      char dbg[80];
      _snprintf(dbg, sizeof(dbg), "SMW: readSram -> %lu bytes\n", r);
      OutputDebugStringA(dbg);
    } else {
      OutputDebugStringA("SMW: SRAM not found (first run?)\n");
    }
  }
  return dst;
}
extern "C" void writeSramImpl(uint8_t *sram) {
  const char *dir = Xbox_GetSramDir();
  if (!dir || !dir[0])
    return;
  DWORD sz = (g_sram_size > 0) ? (DWORD)g_sram_size : 2048;
  char path[MAX_PATH];
  _snprintf(path, sizeof(path), "%s%s.srm", dir, Xbox_GetGameTitle());
  HANDLE f = CreateFile(path, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
  if (f != INVALID_HANDLE_VALUE) {
    DWORD w = 0;
    WriteFile(f, sram, sz, &w, NULL);
    CloseHandle(f);
    char dbg[80];
    _snprintf(dbg, sizeof(dbg), "SMW: writeSram -> %lu bytes\n", w);
    OutputDebugStringA(dbg);
  }
}

/* -----------------------------------------------------------------------
   Save state system
   StateRecorder_Save streams data via writeSaveStateImpl callbacks.
   We accumulate into s_savestate_buf then flush to file on Finalize.
   Load reads file into s_savestate_buf and passes the pointer to RtlSaveLoad.
   Size: InternalSaveLoadSize() = 268712 bytes (~263KB). 4 slots.
----------------------------------------------------------------------- */
/* +sizeof(size_t) for the size header prepended by StateRecorder_Save */
/* Sized for SMW. SMB1/SMBLL cart->ramSize clamped to 2048 before save. */
#define SAVESTATE_SIZE (4 + 27 + 0x10000 + 40 + 3024 + 15 + 224 + 8 + 64 + 66592 + 2048 + 58 + 0x20000 + 4) /* 268716 */
#define SAVESTATE_SLOTS 10

static uint8_t s_savestate_buf[SAVESTATE_SIZE];
static size_t s_savestate_pos = 0;
static uint8_t s_pending_slot = 0xFF; /* slot we are saving to           */

/* Called by StateRecorder_Save before streaming begins */
extern "C" void writeSaveStateInitImpl(void) {
  s_savestate_pos = 0;
  memset(s_savestate_buf, 0, sizeof(s_savestate_buf));
}

/* Called repeatedly with chunks of save state data */
extern "C" void writeSaveStateImpl(uint8_t *data, size_t size) {
  if (s_savestate_pos + size <= SAVESTATE_SIZE) {
    memcpy(s_savestate_buf + s_savestate_pos, data, size);
    s_savestate_pos += size;
  }
}

/* Called after all chunks written - flush to disk */
extern "C" void writeSaveStateFinalizeImpl(void) {
  if (s_pending_slot >= SAVESTATE_SLOTS)
    return;
  const char *dir = Xbox_GetStateDirCreate(s_pending_slot);
  if (dir && dir[0]) {
    char path[MAX_PATH];
    _snprintf(path, sizeof(path), "%s%s_save%d.sav", dir, Xbox_GetGameTitle(), s_pending_slot + 1);
    HANDLE f = CreateFile(path, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if (f != INVALID_HANDLE_VALUE) {
      DWORD w = 0;
      WriteFile(f, s_savestate_buf, (DWORD)s_savestate_pos, &w, NULL);
      CloseHandle(f);
      char dbg[80];
      _snprintf(dbg, sizeof(dbg), "SMW: State slot %d saved (%lu bytes)\n", s_pending_slot + 1, w);
      OutputDebugStringA(dbg);
    }
  }
  s_pending_slot = 0xFF;
}

extern "C" uint8 g_ram[0x20000];
extern "C" bool g_smb1_want_reset;
extern "C" bool g_smbll_want_reset;

/* Save to a slot (0-3). Called from menu. */
extern "C" void Xbox_SaveState(int slot) {
  if (slot < 0 || slot >= SAVESTATE_SLOTS)
    return;
  s_pending_slot = (uint8_t)slot;
  /* Clamp cart->ramSize to 2048 so savestate matches InternalSaveLoadSize().
     SMB1/SMBLL SRAM (8192 bytes) is saved separately via writeSramImpl. */
  int s_saved_ramsize = 0;
  if (s_selected_game != 0 && g_snes->cart->ramSize > 2048) {
    s_saved_ramsize = g_snes->cart->ramSize;
    g_snes->cart->ramSize = 2048;
  }
  RtlSaveLoad(kSaveLoad_Save, (uint8_t *)(intptr_t)slot);
  if (s_saved_ramsize)
    g_snes->cart->ramSize = s_saved_ramsize;
}

/* Load from a slot (0-3). Called from menu. */
extern "C" void Xbox_LoadState(int slot) {
  if (slot < 0 || slot >= SAVESTATE_SLOTS)
    return;
  const char *dir = Xbox_GetStateDir(slot);
  if (!dir || !dir[0]) {
    OutputDebugStringA("SMW: No save state in slot\n");
    return;
  }
  char path[MAX_PATH];
  _snprintf(path, sizeof(path), "%s%s_save%d.sav", dir, Xbox_GetGameTitle(), slot + 1);
  HANDLE f = CreateFile(path, GENERIC_READ, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
  if (f == INVALID_HANDLE_VALUE) {
    OutputDebugStringA("SMW: No save state in slot\n");
    return;
  }
  DWORD r = 0;
  ReadFile(f, s_savestate_buf, SAVESTATE_SIZE, &r, NULL);
  CloseHandle(f);
  if (r < sizeof(size_t))
    return;
  char dbg[80];
  _snprintf(dbg, sizeof(dbg), "SMW: Loading state slot %d (%lu bytes)\n", slot + 1, r);
  OutputDebugStringA(dbg);
  /* Clamp cart->ramSize to 2048 on load to match what was saved. */
  int s_saved_ramsize_load = 0;
  if (s_selected_game != 0 && g_snes->cart->ramSize > 2048) {
    s_saved_ramsize_load = g_snes->cart->ramSize;
    g_snes->cart->ramSize = 2048;
  }
  RtlSaveLoad(kSaveLoad_Load, s_savestate_buf);
  if (s_saved_ramsize_load)
    g_snes->cart->ramSize = s_saved_ramsize_load;
  /* After load: fix state that snes_saveload corrupts.
     snes_saveload forces cpu->e=0 (native mode) and runningWhichVersion=0.
     For SMB1/SMBLL the SNES CPU must run in emulation mode (e=1). */
  if (s_selected_game != 0) {
    g_snes->cpu->e = 1;  /* restore emulation mode */
    g_snes->cpu->xf = 1; /* 8-bit index registers */
    g_snes->cpu->mf = 1; /* 8-bit accumulator */
    g_smb1_want_reset = false;
    g_smbll_want_reset = false;
    if (g_snes->cpu->pc == 0x8000)
      g_snes->cpu->pc = 0x8001;
  }
}

/* Asset helpers (from main.c) */
extern "C" MemBlk FindInAssetArray(int asset, int idx) {
  MemBlk b = {g_asset_ptrs[asset], g_asset_sizes[asset]};
  return FindIndexInMemblk(b, idx);
}
extern "C" const uint8 *FindPtrInAsset(int asset, uint32 addr) {
  MemBlk b = {g_asset_ptrs[asset], g_asset_sizes[asset]};
  return FindAddrInMemblk(b, addr);
}

/* -----------------------------------------------------------------------
   Audio mutex - RtlApuLock/Unlock are no-ops (audio on main thread)
----------------------------------------------------------------------- */
extern "C" void SmwCpuInitialize(void);
extern "C" uint32 PatchBugs(uint32 mode, uint32 addr);
extern "C" void RtlPushApuState(void);

static void Xbox_RunOneFrame(uint32_t inputs) {
  /* All games use RtlRunFrame -> RtlRunFrameCompare -> run_frame()
     This mirrors the PC RM_MINE path exactly. */
  RtlRunFrame(inputs);
}

/* IPS Brick Fix for Super Mario All-Stars (USA) - applied to cart->rom in memory */
static void ApplyBrickFixPatch(uint8_t *rom, int rom_size) {
  static const uint8_t p0[] = {0xA9, 0x01, 0x85, 0xA0, 0x8D, 0x00, 0x16, 0x6B};
  static const uint8_t p1[] = {0xD4, 0x5C, 0x2B, 0xA3};
  static const uint8_t p2[] = {0x22, 0xA0, 0xFF, 0x00};
  static const uint8_t p3[] = {0x22, 0xA0, 0xFF, 0x00};
  static const struct {
    int off;
    int len;
    const uint8_t *data;
  } patches[4] = {{0x007FA0, 8, p0}, {0x007FDC, 4, p1}, {0x01BFB6, 4, p2}, {0x06BDA4, 4, p3}};
  char dbg[128];
  for (int i = 0; i < 4; i++) {
    int off = patches[i].off;
    int len = patches[i].len;
    if (off + len <= rom_size) {
      _snprintf(dbg, sizeof(dbg), "SMW: BrickFix[%d] @0x%06X: %02X%02X->%02X%02X\n", i, off, rom[off], rom[off + 1], patches[i].data[0],
                patches[i].data[1]);
      OutputDebugStringA(dbg);
      memcpy(rom + off, patches[i].data, len);
    } else {
      _snprintf(dbg, sizeof(dbg), "SMW: BrickFix[%d] @0x%06X SKIPPED size=%d\n", i, off, rom_size);
      OutputDebugStringA(dbg);
    }
  }
}

static void Xbox_LoadRomGame(const char **rom_paths) {
  size_t rom_size = 0;
  uint8_t *rom_data = TryLoadFile(rom_paths, &rom_size);
  if (!rom_data)
    Die("ROM file not found");
  /* cart->ram points to g_static_ram (not heap) in RM_MINE mode.
     Null it out before snes_loadRom so cart_load does not free() it. */
  g_snes->cart->ram = NULL;
  g_snes->cart->rom = NULL;
  if (!snes_loadRom(g_snes, rom_data, (int)rom_size))
    Die("snes_loadRom failed");
  free(rom_data);
  extern const uint8 *g_rom;
  g_rom = g_snes->cart->rom;
  /* Apply brick fix patch to ROM in memory */
  ApplyBrickFixPatch((uint8_t *)g_snes->cart->rom, g_snes->cart->romSize);
  if (memcmp(g_rom + 0x7fc0, "Super Mario Bros. LL ", 21) == 0)
    g_rtl_game_info = &kSmbllGameInfo;
  else if (memcmp(g_rom + 0x7fc0, "Super Mario Bros. 1  ", 21) == 0)
    g_rtl_game_info = &kSmb1GameInfo;
  else
    Die("Unrecognised ROM");
  static uint8 s_co[1024];
  for (size_t i = 0; i != g_rtl_game_info->patch_carrys_count; i++) {
    uint8_t *p = SnesRomPtr(g_rtl_game_info->patch_carrys[i]);
    s_co[i] = *p;
    *p = 0;
  }
  g_rtl_game_info->initialize();
  snes_reset(g_snes, true);
  /* Set CPU registers to SNES reset state.
     pc=0x8000 triggers VectorReset check in Smb1/SmbllRunOneFrameOfGame.
     sp=0x01FF matches the SNES hardware reset value.
     Do NOT use cpu_reset() - reads reset vector which may not be 0x8000. */
  g_snes->cpu->pc = 0x8000;
  g_snes->cpu->k = 0;
  g_snes->cpu->sp = 0x01FF;
  g_snes->cpu->e = 1; /* emulation mode after reset */
  g_snes->cpu->i = 1; /* interrupts disabled after reset */
  PatchBugs(1, 0);
  g_sram = g_snes->cart->ram;
  g_sram_size = g_snes->cart->ramSize;
}
static uint8_t s_pixels[256 * 4 * 240];
static uint8_t s_my_pixels[256 * 4 * 240];
static int s_ppu_render_flags = 0;

/* RtlReset override: for ROM games, restore cpu->pc=0x8000 after snes_reset
   so the decompiled VectorReset fires on the next frame. */
extern "C" void RtlReset(int mode);
extern "C" void Xbox_Reset(void) {
  RtlReset(1); /* mode=1 = keep SRAM, matches PC kKeys_Reset handler */
  if (s_selected_game != 0) {
    g_snes->cpu->pc = 0x8000;
    g_snes->cpu->k = 0;
    /* Re-alias g_my_ppu -> snes->ppu after ppu_reset cleared it */
    g_my_ppu = g_snes->ppu;
    PpuBeginDrawing(g_my_ppu, s_my_pixels, 256 * 4, s_ppu_render_flags);
  }
}

/* Per-game title helper - used by xbox_config.cpp and save path builders */
extern "C" const char *Xbox_GetGameTitle(void) {
  return (g_rtl_game_info && g_rtl_game_info->title) ? g_rtl_game_info->title : "smw";
}

extern "C" void RtlApuLock(void) {
}
extern "C" void RtlApuUnlock(void) {
}

/* -----------------------------------------------------------------------
   RtlDrawPpuFrame - renders PPU into D3D framebuffer
   Matches pattern from main.c: separate pixel buffers at 256*4 pitch,
   then copy row-by-row to D3D buffer.
----------------------------------------------------------------------- */
static int s_snes_width = 256;
static int s_snes_height = 224;

/* Apply g_config renderer settings.
   Updates g_new_ppu and g_no_sprite_limits globals read by ppu_xbox.c.
   Call after config load and after menu toggles either setting. */
extern "C" void Xbox_ApplyRenderFlags(void) {
  g_new_ppu = true;             /* old renderer not available in Xbox port */
  g_config.new_renderer = true; /* keep config in sync */
  g_no_sprite_limits = g_config.no_sprite_limits;
  s_ppu_render_flags = 0;
  if (g_config.new_renderer)
    s_ppu_render_flags |= kPpuRenderFlags_NewRenderer;
  if (g_config.no_sprite_limits)
    s_ppu_render_flags |= kPpuRenderFlags_NoSpriteLimits;
}

extern "C" void RtlDrawPpuFrame(uint8_t *pixel_buffer, size_t pitch, uint32_t render_flags) {
  if (s_selected_game != 0) {
    /* SMB1/SMBLL: pixels already rendered into s_my_pixels scanline-by-scanline
       during Smb1RunOneFrameOfGame via snes_handle_pos_stuff -> ppu_runLine.
       Do NOT call ppu_runLine again - just let the memcpy below copy them. */
  } else {
    g_rtl_game_info->draw_ppu_frame();
  }
  uint8_t *src = g_other_image ? s_my_pixels : s_pixels;
  for (int y = 0; y < s_snes_height; y++)
    memcpy(pixel_buffer + y * pitch, src + y * 256 * 4, s_snes_width * 4);
}

/* -----------------------------------------------------------------------
   Die / Warning
----------------------------------------------------------------------- */
extern "C" void __declspec(noreturn) Die(const char *msg) {
  char buf[512];
  _snprintf(buf, sizeof(buf), "SMW FATAL: %s\n", msg);
  OutputDebugStringA(buf);
  for (;;)
    Sleep(1000);
}
extern "C" void Warning(const char *msg) {
  char buf[512];
  _snprintf(buf, sizeof(buf), "SMW WARNING: %s\n", msg);
  OutputDebugStringA(buf);
}

/* -----------------------------------------------------------------------
   _ftol2_sse shim
----------------------------------------------------------------------- */
extern "C" long __cdecl _ftol(double);
extern "C" long __cdecl _ftol2_sse(double f) {
  return _ftol(f);
}

/* -----------------------------------------------------------------------
   Drive mounting
----------------------------------------------------------------------- */
typedef struct {
  USHORT Length, MaximumLength;
  PCHAR Buffer;
} XBOX_STRING;
static void BuildStr(XBOX_STRING &s, const char *z) {
  s.Length = (USHORT)strlen(z);
  s.MaximumLength = s.Length + 1;
  s.Buffer = (PCHAR)z;
}
extern "C" LONG __stdcall IoCreateSymbolicLink(XBOX_STRING *, XBOX_STRING *);
extern "C" LONG __stdcall IoDeleteSymbolicLink(XBOX_STRING *);
static void MountDrive(const char *letter, const char *device) {
  char dos[32];
  _snprintf(dos, sizeof(dos), "\\??\\%s", letter);
  XBOX_STRING link, target;
  BuildStr(link, dos);
  BuildStr(target, device);
  IoDeleteSymbolicLink(&link);
  IoCreateSymbolicLink(&link, &target);
}
extern "C" void Xbox_EnsureSaveDir(void) {
  /* Only mount the HDD so U: (UDATA) is accessible.
     All save paths are resolved later via Xbox_ResolveSavePaths()
     once we know which game is running. */
  MountDrive("E:", "\\Device\\Harddisk0\\Partition1");
}

/* -----------------------------------------------------------------------
   Asset loading (equivalent to main.c's LoadAssets)
----------------------------------------------------------------------- */
static bool VerifyAssets(const uint8_t *d, size_t n) {
  static const uint8_t sig[] = {kAssets_Sig};
  return n >= 88u + kNumberOfAssets * 4u && memcmp(d, sig, 48) == 0 && *(uint32_t *)(d + 80) == kNumberOfAssets;
}
static void LoadAssets(void) {
  /* Assets always in D:\Media\ - D: is always the launch drive on Xbox */
  size_t len = 0;
  uint8_t *data = (uint8_t *)ReadWholeFile("D:\\Media\\smw_assets.dat", &len);
  if (!data) {
    size_t bl = 0, rl = 0;
    uint8_t *bps = (uint8_t *)ReadWholeFile("D:\\Media\\smw_assets.bps", &bl);
    uint8_t *rom = (uint8_t *)ReadWholeFile("D:\\Media\\smw.sfc", &rl);
    if (bps && rom)
      data = (uint8_t *)ApplyBps(rom, rl, bps, bl, &len);
    if (bps)
      free(bps);
    if (rom)
      free(rom);
  }
  if (!data)
    Die("D:\\Media\\smw_assets.dat not found");
  if (!VerifyAssets(data, len))
    Die("smw_assets.dat corrupt");
  uint32_t off = 88 + kNumberOfAssets * 4 + *(uint32_t *)(data + 84);
  for (int i = 0; i < kNumberOfAssets; i++) {
    uint32_t sz = *(uint32_t *)(data + 88 + i * 4);
    off = (off + 3) & ~3;
    g_asset_sizes[i] = sz;
    g_asset_ptrs[i] = data + off;
    off += sz;
  }
}

/* -----------------------------------------------------------------------
   Frame timing
   D3DPRESENT_INTERVAL_ONE makes Present() block until vsync (~16.67ms).
   No extra sleep needed. Loop order for minimum input latency:
     Present() returns at vsync
     -> Poll input immediately (freshest possible read)
     -> Run game logic with that input
     -> Render PPU frame
     -> Present() (blocks until next vsync)
   This gives 1-frame input latency (input read -> displayed next frame).
----------------------------------------------------------------------- */
static int s_frame_ctr = 0;

/* -----------------------------------------------------------------------
   MAIN
----------------------------------------------------------------------- */
void __cdecl main(void) {
  LoadAssets();
  Xbox_EnsureSaveDir();

  s_snes_width = 256;
  s_snes_height = 224;
  /* Default renderer settings - overridden by config load below */
  g_config.new_renderer = true;
  g_config.no_sprite_limits = true;

  /* SnesInit(NULL,0) forces the RM_MINE else-branch in common_cpu_infra.c
     (the ROM loading path is commented out in the new repo, so passing ROM
     leaves g_rtl_game_info unset -> crash). After init, manually set g_rom
     and re-call SmwCpuInitialize() so it applies the critical ROM patches
     (0x843B, 0x2DDA2, 0xCA5AC, SPC upload loop etc.) that the decompiled
     game code depends on for correct pipe exits, entrances, etc. */
  Snes *snes = SnesInit(NULL, 0);
  if (!snes)
    Die("SnesInit failed");
  /* Apply ROM patches via SmwCpuInitialize.
     kRom points into asset memory which may be read-only at the OS level.
     SmwCpuInitialize writes to ROM bytes via SnesRomPtr, so we need a
     writable copy of the ROM. */
  extern const uint8 *g_rom;
  static uint8 s_rom_writable[512 * 1024 + 512]; /* 512KB + header room */
  size_t rom_copy_size = kRom_SIZE < sizeof(s_rom_writable) ? kRom_SIZE : sizeof(s_rom_writable);
  memcpy(s_rom_writable, kRom, rom_copy_size);
  g_rom = s_rom_writable; /* writable copy for patch writes */
  SmwCpuInitialize();     /* now patches can write to ROM bytes safely */

  /* Point PPUs at our fixed-pitch pixel buffers */
  PpuBeginDrawing(snes->ppu, s_pixels, 256 * 4, s_ppu_render_flags);
  PpuBeginDrawing(g_my_ppu, s_my_pixels, 256 * 4, s_ppu_render_flags);

  /* D3D */
  if (FAILED(Xbox_D3D_Init()))
    Die("D3D init failed");

  /* Audio */
  if (SUCCEEDED(Xbox_Audio_Init()))
    Xbox_Audio_StartThread();

  /* SPC player */
  g_spc_player = SmwSpcPlayer_Create();
  g_spc_player->initialize(g_spc_player);

  /* Input & menu */
  Xbox_Input_Init();
  Xbox_Menu_Init();

  /* Detect available games and load saved choice */
  {
    size_t sz = 0;
    uint8_t *d;
    d = TryLoadFile(kSmb1Paths, &sz);
    if (d) {
      free(d);
      s_has_smb1 = true;
    }
    d = TryLoadFile(kSmbllPaths, &sz);
    if (d) {
      free(d);
      s_has_smbll = true;
    }
  }
  /* Resolve SMW UDATA container first - cache dir for game choice file */
  Xbox_ResolveSavePaths(0);
  /* Cache the SMW sram dir now - SaveGameChoice/LoadGameChoice always use this */
  if (Xbox_GetSramDir() && Xbox_GetSramDir()[0])
    _snprintf(s_game_choice_dir, sizeof(s_game_choice_dir), "%s", Xbox_GetSramDir());
  s_selected_game = LoadGameChoice();
  if (s_selected_game == 1 && !s_has_smb1)
    s_selected_game = 0;
  if (s_selected_game == 2 && !s_has_smbll)
    s_selected_game = 0;

  /* Re-resolve UDATA with the correct game now that we know which one */
  if (s_selected_game != 0)
    Xbox_ResolveSavePaths(s_selected_game);

  /* Load ROM if SMB1/SMBLL - sets g_rtl_game_info to correct game */
  if (s_selected_game == 1)
    Xbox_LoadRomGame(kSmb1Paths);
  else if (s_selected_game == 2)
    Xbox_LoadRomGame(kSmbllPaths);

  /* Now g_rtl_game_info->title is correct for whichever game is running.
     Load SRAM and config using the right per-game filenames. */
  RtlReadSram();
  Xbox_Config_Load();
  Xbox_ApplyRenderFlags();

  if (s_selected_game != 0) {
    /* Log what game was detected */
    char dbg[64];
    _snprintf(dbg, sizeof(dbg), "SMW: ROM game loaded: %s\n", g_rtl_game_info->title);
    OutputDebugStringA(dbg);
    /* Make g_my_ppu alias g_snes->ppu so RtlRunFrameCompare renders
       via the SNES emulator PPU state (set up by snes_reset) */
    g_my_ppu = snes->ppu;
    PpuBeginDrawing(g_my_ppu, s_my_pixels, 256 * 4, s_ppu_render_flags);
    /* SMB1/SMBLL use emulated APU, not our custom SPC player path */
    g_use_my_apu_code = false;
  }

  /* Select SPC player based on game */
  if (s_selected_game != 0) {
    g_spc_player = SmasSpcPlayer_Create();
    g_spc_player->initialize(g_spc_player);
  }

  /* Pre-poll input before first frame */
  Xbox_Input_Poll();

  bool running = true;
  while (running) {
    /* ---------------------------------------------------------------
       GAME FRAME - tight loop for minimum input latency.
       Present(INTERVAL_ONE) already blocks until vsync so no extra
       sleep is needed. Input is polled RIGHT AFTER Present() returns
       so it captures the freshest controller state before game logic.
    --------------------------------------------------------------- */
    if (Xbox_Menu_ExitRequested()) {
      running = false;
      break;
    }

    if (!Xbox_Menu_IsOpen() && !Xbox_Menu_IsPaused()) {
      /* ---------------------------------------------------------------
         Render previous frame's PPU output + Present().
         Present() blocks here until vsync fires.
         We render BEFORE polling so the display pipeline is busy while
         we wait for vsync, and input is read right at the vsync edge.
         Skip on the very first iteration - no game frame has run yet.
      --------------------------------------------------------------- */
      /* Present previous frame - blocks until vsync.
         Only GPU work here (texture already uploaded), no CPU PPU render. */
      if (s_frame_ctr > 0)
        Xbox_D3D_EndDraw();

      /* Poll input IMMEDIATELY after vsync - freshest possible read */
      Xbox_Input_Poll();
      Xbox_Menu_Update();

      uint32_t p1 = Xbox_Input_GetJoypad(0);
      uint32_t p2 = Xbox_Input_GetJoypad(1);
      uint32_t ctrl_flags = (1u << 30);
      if (p2)
        ctrl_flags |= (1u << 31);
      uint32_t inputs = p1 | (p2 << 12) | ctrl_flags;

      /* Run game logic */
      if (Xbox_Menu_IsTurbo()) {
        for (int tf = 0; tf < 3; tf++) {
          Xbox_RunOneFrame(inputs);
          Xbox_Audio_PushFrame();
          s_frame_ctr++;
        }
      }
      Xbox_RunOneFrame(inputs);
      s_frame_ctr++;

      /* Render PPU to framebuffer and upload texture NOW, right after game.
         This decouples variable PPU render time from the vsync deadline.
         EndDraw at top of next iteration just does Present (GPU only). */
      {
        uint8_t *pbuf;
        int pitch;
        Xbox_D3D_BeginDraw(s_snes_width, s_snes_height, &pbuf, &pitch);
        RtlDrawPpuFrame(pbuf, pitch, s_ppu_render_flags);
        Xbox_D3D_PrepareFrame(); /* upload texture, no Present */
      }

      /* Render audio after game logic */
      Xbox_Audio_PushFrame();

    } else if (Xbox_Menu_IsOpen()) {
      Xbox_Input_Poll();
      Xbox_Menu_Update();
      Xbox_D3D_DrawMenuOverlay();
      Xbox_Audio_PushSilence(); /* pause audio while menu is open */

    } else {
      /* Paused */
      Xbox_Input_Poll();
      Xbox_Menu_Update();
      Xbox_D3D_DrawDimOverlay();
      Xbox_Audio_PushSilence(); /* pause audio while paused */
      Sleep(16);
    }
  }

  RtlWriteSram();
  Xbox_Config_Save();
  Xbox_Menu_Shutdown();
  Xbox_Input_Shutdown();
  Xbox_Audio_Shutdown();
  Xbox_D3D_Shutdown();

  LD_LAUNCH_DASHBOARD ld;
  ZeroMemory(&ld, sizeof(ld));
  ld.dwReason = XLD_LAUNCH_DASHBOARD_MAIN_MENU;
  XLaunchNewImage(NULL, (LAUNCH_DATA *)&ld);
}