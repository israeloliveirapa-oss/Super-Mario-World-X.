/*==========================================================================
  xbox_audio.cpp  -  DirectSound streaming audio for SMW Xbox port

  DESIGN: SPC audio is rendered on the MAIN thread (after RtlRunFrame),
  eliminating mutex contention that caused main thread stalls of up to 16ms.

  Old design: audio thread called RtlRenderAudio while holding the mutex.
  RtlRenderAudio runs SPC DSP emulation (~16ms of CPU work) while holding
  the mutex. Main thread calls RtlPushApuState (also needs mutex) and stalls.
  Result: main thread hiccups every frame = sluggish/laggy feel.

  New design:
  - Main thread calls Xbox_Audio_PushFrame() once per game frame.
    This calls RtlRenderAudio WITHOUT any mutex (SPC runs freely).
    The rendered samples are written into a lock-free ring buffer.
  - Audio thread ONLY copies from the ring buffer to DirectSound.
    It never calls RtlRenderAudio. No mutex needed.
  - RtlApuLock/Unlock are now no-ops. RtlPushApuState runs freely.
==========================================================================*/

#include "xbox_platform.h"

extern "C" {
void RtlRenderAudio(short* audio_buffer, int samples, int channels);
}

/* -----------------------------------------------------------------------
   Lock-free ring buffer: main thread writes, audio thread reads.
   Size = 8 frames of audio = 133ms headroom. More than enough.
----------------------------------------------------------------------- */
#define RING_BLOCKS 8
#define RING_BYTES (RING_BLOCKS * AUDIO_BYTES_PER_BLOCK)

static short s_ringBuf[RING_BLOCKS * AUDIO_FRAMES_PER_BLOCK * AUDIO_CHANNELS];
static volatile LONG s_writePos = 0; /* in bytes, written by main thread */
static volatile LONG s_readPos = 0;  /* in bytes, consumed by audio thread */

static LPDIRECTSOUND8 g_pDSound = NULL;
static LPDIRECTSOUNDBUFFER g_pStreamBuf = NULL;
static DWORD g_dsWritePos = 0;
static DWORD g_dsBufSize = 0;

static HANDLE s_audioThread = NULL;
static volatile bool s_audioRunning = false;

/* Volume multiplier: 256=1.0x 320=1.25x 384=1.5x 448=1.75x 512=2.0x */
int g_audio_volume = 512; /* 2.0x gain */

/* -----------------------------------------------------------------------
   Xbox_Audio_PushFrame - called by main thread once per game frame.
   Renders one block of SPC audio into the ring buffer.
----------------------------------------------------------------------- */
extern "C" void Xbox_Audio_PushFrame(void) {
  /* Check there's space in the ring buffer (shouldn't fill up at 60fps) */
  LONG wp = s_writePos;
  LONG rp = s_readPos;
  LONG used = (wp - rp + RING_BYTES) % RING_BYTES;
  if (used + AUDIO_BYTES_PER_BLOCK > RING_BYTES)
    return; /* ring full - skip this frame rather than stall */

  /* Render directly into ring buffer slot */
  LONG slot = (wp / AUDIO_BYTES_PER_BLOCK) % RING_BLOCKS;
  short* dst = s_ringBuf + slot * AUDIO_FRAMES_PER_BLOCK * AUDIO_CHANNELS;

  /* RtlRenderAudio acquires g_audioMutex internally via RtlApuLock.
     Since RtlApuLock is now a no-op, this runs without any blocking. */
  RtlRenderAudio(dst, AUDIO_FRAMES_PER_BLOCK, AUDIO_CHANNELS);

  /* Amplify output - SPC audio is quiet relative to other Xbox games.
     Multiply by g_audio_volume (256 = 1.0x, 384 = 1.5x, 512 = 2.0x). */
  {
    int vol = g_audio_volume;
    if (vol != 256) {
      for (int i = 0; i < AUDIO_FRAMES_PER_BLOCK * AUDIO_CHANNELS; i++) {
        int s = (dst[i] * vol) >> 8;
        if (s > 32767)
          s = 32767;
        if (s < -32768)
          s = -32768;
        dst[i] = (short)s;
      }
    }
  }

  /* Advance write pointer (atomic on x86) */
  s_writePos = (wp + AUDIO_BYTES_PER_BLOCK) % RING_BYTES;
}

/* -----------------------------------------------------------------------
   Xbox_Audio_PushSilence - push a silent frame when menu is open.
   Keeps the ring buffer fed so DirectSound doesn't repeat stale audio.
----------------------------------------------------------------------- */
extern "C" void Xbox_Audio_PushSilence(void) {
  LONG wp = s_writePos;
  LONG rp = s_readPos;
  LONG used = (wp - rp + RING_BYTES) % RING_BYTES;
  if (used + AUDIO_BYTES_PER_BLOCK > RING_BYTES)
    return;
  LONG slot = (wp / AUDIO_BYTES_PER_BLOCK) % RING_BLOCKS;
  short* dst = s_ringBuf + slot * AUDIO_FRAMES_PER_BLOCK * AUDIO_CHANNELS;
  ZeroMemory(dst, AUDIO_BYTES_PER_BLOCK);
  s_writePos = (wp + AUDIO_BYTES_PER_BLOCK) % RING_BYTES;
}

/* -----------------------------------------------------------------------
   Audio thread - ONLY copies ring buffer data to DirectSound.
   Never calls RtlRenderAudio. Never blocks the main thread.
----------------------------------------------------------------------- */
static DWORD WINAPI Xbox_Audio_Thread(LPVOID param) {
  while (s_audioRunning) {
    if (g_pStreamBuf) {
      /* Check how much DirectSound has consumed */
      DWORD playCursor = 0, ignored = 0;
      g_pStreamBuf->GetCurrentPosition(&playCursor, &ignored);

      DWORD dsAvail;
      if (g_dsWritePos <= playCursor)
        dsAvail = playCursor - g_dsWritePos;
      else
        dsAvail = g_dsBufSize - g_dsWritePos + playCursor;

      /* Copy from ring buffer to DirectSound */
      while (dsAvail >= AUDIO_BYTES_PER_BLOCK) {
        LONG wp = s_writePos;
        LONG rp = s_readPos;
        LONG avail = (wp - rp + RING_BYTES) % RING_BYTES;
        if (avail < AUDIO_BYTES_PER_BLOCK)
          break; /* no rendered audio ready yet */

        LONG slot = (rp / AUDIO_BYTES_PER_BLOCK) % RING_BLOCKS;
        BYTE* src = (BYTE*)(s_ringBuf + slot * AUDIO_FRAMES_PER_BLOCK * AUDIO_CHANNELS);
        DWORD toWrite = AUDIO_BYTES_PER_BLOCK;

        void* p1 = NULL;
        void* p2 = NULL;
        DWORD s1 = 0, s2 = 0;
        if (SUCCEEDED(g_pStreamBuf->Lock(g_dsWritePos, toWrite, &p1, &s1, &p2, &s2, 0))) {
          if (p1 && s1) {
            memcpy(p1, src, s1);
          }
          if (p2 && s2) {
            memcpy(p2, src + s1, s2);
          }
          g_pStreamBuf->Unlock(p1, s1, p2, s2);
          g_dsWritePos = (g_dsWritePos + toWrite) % g_dsBufSize;
          s_readPos = (rp + AUDIO_BYTES_PER_BLOCK) % RING_BYTES;
          dsAvail -= toWrite;
        } else {
          break;
        }
      }
    }

    Sleep(4);
  }
  return 0;
}

/* -----------------------------------------------------------------------
   RtlApuLock / RtlApuUnlock - now no-ops.
   SPC rendering happens on main thread with no mutex needed.
   RtlPushApuState still calls these - making them no-ops eliminates
   all mutex contention between main thread and audio thread.
----------------------------------------------------------------------- */
/* RtlApuLock/Unlock defined in xbox_main.cpp */

HRESULT Xbox_Audio_Init(void) {
  HRESULT hr = DirectSoundCreate(NULL, &g_pDSound, NULL);
  if (FAILED(hr)) {
    OutputDebugStringA("SMW: DirectSoundCreate failed\n");
    return hr;
  }

  g_dsBufSize = AUDIO_BUF_BYTES;
  g_dsWritePos = 0;
  s_writePos = 0;
  s_readPos = 0;

  WAVEFORMATEX wfx;
  ZeroMemory(&wfx, sizeof(wfx));
  wfx.wFormatTag = WAVE_FORMAT_PCM;
  wfx.nChannels = AUDIO_CHANNELS;
  wfx.nSamplesPerSec = AUDIO_SAMPLE_RATE;
  wfx.wBitsPerSample = AUDIO_BITS;
  wfx.nBlockAlign = wfx.nChannels * wfx.wBitsPerSample / 8;
  wfx.nAvgBytesPerSec = wfx.nSamplesPerSec * wfx.nBlockAlign;

  DSBUFFERDESC desc;
  ZeroMemory(&desc, sizeof(desc));
  desc.dwSize = sizeof(desc);
  desc.dwFlags = DSBCAPS_CTRLVOLUME;
  desc.dwBufferBytes = g_dsBufSize;
  desc.lpwfxFormat = &wfx;
  desc.lpMixBins = NULL;
  desc.dwInputMixBin = 0;

  hr = g_pDSound->CreateSoundBuffer(&desc, &g_pStreamBuf, NULL);
  if (FAILED(hr)) {
    OutputDebugStringA("SMW: CreateSoundBuffer failed\n");
    return hr;
  }

  /* Silence the buffer */
  void* p1 = NULL;
  void* p2 = NULL;
  DWORD s1 = 0, s2 = 0;
  if (SUCCEEDED(g_pStreamBuf->Lock(0, g_dsBufSize, &p1, &s1, &p2, &s2, 0))) {
    if (p1)
      ZeroMemory(p1, s1);
    if (p2)
      ZeroMemory(p2, s2);
    g_pStreamBuf->Unlock(p1, s1, p2, s2);
  }

  g_pStreamBuf->Play(0, 0, DSBPLAY_LOOPING);
  g_pStreamBuf->SetVolume(DSBVOLUME_MAX); /* ensure no DS attenuation */
  OutputDebugStringA("SMW: Audio init OK (main-thread render)\n");
  return S_OK;
}

extern "C" void Xbox_Audio_StartThread(void) {
  /* No mutex needed in new design */
  s_audioRunning = true;
  s_audioThread = CreateThread(NULL, 0, Xbox_Audio_Thread, NULL, 0, NULL);
  if (!s_audioThread) {
    OutputDebugStringA("SMW: Audio CreateThread failed\n");
    s_audioRunning = false;
  } else {
    OutputDebugStringA("SMW: Audio thread started\n");
  }
}

void Xbox_Audio_Shutdown(void) {
  s_audioRunning = false;
  if (s_audioThread) {
    WaitForSingleObject(s_audioThread, 2000);
    CloseHandle(s_audioThread);
    s_audioThread = NULL;
  }
  if (g_pStreamBuf) {
    g_pStreamBuf->Stop();
    g_pStreamBuf->Release();
    g_pStreamBuf = NULL;
  }
  if (g_pDSound) {
    g_pDSound->Release();
    g_pDSound = NULL;
  }
}