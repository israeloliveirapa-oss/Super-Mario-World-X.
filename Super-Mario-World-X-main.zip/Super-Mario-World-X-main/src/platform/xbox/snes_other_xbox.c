/*
 * snes_other_xbox.c - Xbox wrapper for snes/snes_other.c
 *
 * snes_other.c calls dsp_getSamples() with 3 args. Fix via macro AFTER
 * including dsp.h so the declaration isn't mangled.
 */
#include "dsp.h"
#define dsp_getSamples(dsp, buf, frames) dsp_getSamples(dsp, buf, frames, 2)
#include "../../snes/snes_other.c"