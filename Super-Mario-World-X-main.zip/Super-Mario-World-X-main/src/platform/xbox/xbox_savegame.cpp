/*==========================================================================
  xbox_savegame.cpp - UDATA save path resolution for SMW Xbox port

  At startup, resolves the SRAM/INI UDATA container via XCreateSaveGame.
  State containers are resolved lazily on first save (write creates,
  read returns NULL if not found - no empty folders created).

  Same pattern as zelda3 xbox_savegame.cpp exactly.

  Dashboard shows:
    "Super Mario World - Game Save"   sram + config (created at startup)
    "Super Mario World - State 1"     state (created on first save to slot 1)
    ...
    "Super Mario World - State 10"    state (created on first save to slot 10)
==========================================================================*/
#include <stdio.h>
#include <string.h>

#include "xbox_platform.h"

static char s_sram_dir[MAX_PATH] = "";
static char s_state_dir[10][MAX_PATH];
static const char* kSaveImageSrc = "D:\\Media\\saveimage.xbx";
static const char* kSaveImageMeta = "saveimage.xbx";

/* Per-game container display names - short so they fit dashboard */
static const wchar_t* s_sram_name = L"SMW - Game Save";
static const wchar_t* s_state_fmt = L"SMW - State %d";

/* -----------------------------------------------------------------------
   ResolveContainer - open or create a UDATA save game container.
   createIfMissing=true  -> OPEN_ALWAYS  (creates if not found)
   createIfMissing=false -> OPEN_EXISTING (returns false if not found)
----------------------------------------------------------------------- */
static bool ResolveContainer(const wchar_t* name, char* dirOut, size_t dirSize, bool createIfMissing) {
  DWORD disp = createIfMissing ? OPEN_ALWAYS : OPEN_EXISTING;
  DWORD ret = XCreateSaveGame("U:\\", name, disp, 0, dirOut, (UINT)dirSize);

  if (ret != ERROR_SUCCESS) {
    if (createIfMissing) {
      char dbg[128];
      _snprintf(dbg, sizeof(dbg), "SMW: XCreateSaveGame('%S') failed: %lu\n", name, ret);
      OutputDebugStringA(dbg);
    }
    return false;
  }

  /* Ensure trailing backslash */
  size_t len = strlen(dirOut);
  if (len > 0 && dirOut[len - 1] != '\\') {
    dirOut[len] = '\\';
    dirOut[len + 1] = '\0';
  }

  /* Copy save thumbnail and write info.txt */
  char path[MAX_PATH];
  _snprintf(path, sizeof(path), "%s%s", dirOut, kSaveImageMeta);
  CopyFile(kSaveImageSrc, path, FALSE);

  _snprintf(path, sizeof(path), "%sinfo.txt", dirOut);
  HANDLE h = CreateFile(path, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
  if (h != INVALID_HANDLE_VALUE) {
    char txt[128];
    DWORD wr = 0;
    _snprintf(txt, sizeof(txt), "Save: %S\r\nDir:  %s\r\n", name, dirOut);
    WriteFile(h, txt, (DWORD)strlen(txt), &wr, NULL);
    CloseHandle(h);
  }
  return true;
}

/* -----------------------------------------------------------------------
   Xbox_ResolveSavePaths - call once at startup before any file I/O.
   game: 0=SMW, 1=SMB1, 2=SMBLL  (sets display names accordingly)
   Resolves the SRAM/INI container only. State containers are lazy.
----------------------------------------------------------------------- */
extern "C" void Xbox_ResolveSavePaths(int game) {
  /* Set per-game display names */
  switch (game) {
  case 1:
    s_sram_name = L"SMB1 - Game Save";
    s_state_fmt = L"SMB1 - State %d";
    break;
  case 2:
    s_sram_name = L"SMBLL - Game Save";
    s_state_fmt = L"SMBLL - State %d";
    break;
  default:
    s_sram_name = L"SMW - Game Save";
    s_state_fmt = L"SMW - State %d";
    break;
  }

  if (!ResolveContainer(s_sram_name, s_sram_dir, sizeof(s_sram_dir), true)) {
    OutputDebugStringA("SMW: Failed to create SRAM UDATA container\n");
    return;
  }
  for (int i = 0; i < 10; i++)
    s_state_dir[i][0] = '\0';

  char dbg[128];
  _snprintf(dbg, sizeof(dbg), "SMW: SRAM/INI UDATA: %s\n", s_sram_dir);
  OutputDebugStringA(dbg);
}

/* -----------------------------------------------------------------------
   Path accessors - used directly by xbox_main.cpp
----------------------------------------------------------------------- */
extern "C" const char* Xbox_GetSramDir(void) {
  return s_sram_dir;
}

static const char* GetStateDirInternal(int slot0based, bool create) {
  if (slot0based < 0 || slot0based > 9)
    return NULL;

  if (s_state_dir[slot0based][0] == '\0') {
    wchar_t name[64];
    _snwprintf(name, 64, s_state_fmt, slot0based + 1);
    if (!ResolveContainer(name, s_state_dir[slot0based], sizeof(s_state_dir[slot0based]), create))
      return NULL;
  }
  return s_state_dir[slot0based];
}

/* Read - returns NULL if container doesn't exist (won't create it) */
extern "C" const char* Xbox_GetStateDir(int slot0based) {
  return GetStateDirInternal(slot0based, false);
}

/* Write - creates container on first save to this slot */
extern "C" const char* Xbox_GetStateDirCreate(int slot0based) {
  return GetStateDirInternal(slot0based, true);
}