/*==========================================================================
  xbox_config.cpp - Save/load smw.ini for Xbox port
  Based directly on zelda3 xbox_config.cpp pattern.
==========================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "xbox_platform.h"

extern "C" const char* Xbox_GetGameTitle(void);
extern "C" const char* Xbox_GetSramDir(void);

static const char* Xbox_ConfigPath(void) {
  static char s_path[MAX_PATH];
  const char* dir = Xbox_GetSramDir();
  if (dir && dir[0])
    _snprintf(s_path, sizeof(s_path), "%s%s.ini", dir, Xbox_GetGameTitle());
  else
    s_path[0] = '\0'; /* UDATA not resolved yet - no fallback */
  return s_path;
}

extern "C" void Xbox_D3D_SetDispMode(int v);
extern "C" int Xbox_D3D_GetDispMode(void);

/* g_config fields accessed via extern C - avoids C/C++ linkage issues */
extern "C" {
#include "../../config.h"
#include "../../types.h"
}

extern "C" void Xbox_Config_Save(void) {
  {
    char _p[80];
    _snprintf(_p, sizeof(_p), "SMW: Config saving to %s\n", Xbox_ConfigPath());
    OutputDebugStringA(_p);
  }
  FILE* f = fopen(Xbox_ConfigPath(), "w");
  if (!f) {
    OutputDebugStringA("SMW: Config FAILED to open for write\n");
    return;
  }

  fprintf(f, "# SMW Xbox config - edit via in-game menu (L3)\r\n\r\n");
  fprintf(f, "[Graphics]\r\n");
  fprintf(f, "DisplayMode = %d\r\n", Xbox_D3D_GetDispMode());
  fprintf(f, "NoSpriteLimits = %d\r\n", g_config.no_sprite_limits ? 1 : 0);
  fprintf(f, "NewRenderer = %d\r\n", g_config.new_renderer ? 1 : 0);
  fprintf(f, "\r\n[Sound]\r\n");
  fprintf(f, "EnableAudio = %d\r\n", g_config.enable_audio ? 1 : 0);
  fprintf(f, "\r\n[Game]\r\n");
  fprintf(f, "Autosave = %d\r\n", g_config.autosave ? 1 : 0);
  fprintf(f, "DisableFrameDelay = %d\r\n", g_config.disable_frame_delay ? 1 : 0);
  fprintf(f, "\r\n");
  fclose(f);
  OutputDebugStringA("SMW: Config saved OK\n");
}

extern "C" void Xbox_Config_Load(void) {
  {
    char _p[80];
    _snprintf(_p, sizeof(_p), "SMW: Config loading from %s\n", Xbox_ConfigPath());
    OutputDebugStringA(_p);
  }
  FILE* f = fopen(Xbox_ConfigPath(), "r");
  if (!f) {
    OutputDebugStringA("SMW: Config not found - using defaults\n");
    return;
  }

  char line[256];
  while (fgets(line, sizeof(line), f)) {
    char* nl = line + strlen(line) - 1;
    while (nl >= line && (*nl == '\r' || *nl == '\n'))
      *nl-- = 0;
    if (line[0] == '#' || line[0] == '[' || line[0] == 0)
      continue;
    char* eq = strchr(line, '=');
    if (!eq)
      continue;
    *eq = 0;
    char *key = line, *val = eq + 1;
    while (*key == ' ')
      key++;
    char* ke = key + strlen(key) - 1;
    while (ke > key && *ke == ' ')
      *ke-- = 0;
    while (*val == ' ')
      val++;

    if (!strcmp(key, "DisplayMode"))
      Xbox_D3D_SetDispMode(atoi(val));
    else if (!strcmp(key, "NoSpriteLimits"))
      g_config.no_sprite_limits = atoi(val) != 0;
    else if (!strcmp(key, "NewRenderer"))
      g_config.new_renderer = atoi(val) != 0;
    else if (!strcmp(key, "EnableAudio"))
      g_config.enable_audio = atoi(val) != 0;
    else if (!strcmp(key, "Autosave"))
      g_config.autosave = atoi(val) != 0;
    else if (!strcmp(key, "DisableFrameDelay"))
      g_config.disable_frame_delay = atoi(val) != 0;
  }
  fclose(f);

  char buf[128];
  _snprintf(buf, sizeof(buf), "SMW: Config loaded OK - disp=%d nosprite=%d\n", Xbox_D3D_GetDispMode(), g_config.no_sprite_limits);
  OutputDebugStringA(buf);
}