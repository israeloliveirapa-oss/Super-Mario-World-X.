/*==========================================================================
  xbox_platform.h - Master Xbox platform header for SMW Xbox port
  Only included by xbox_*.cpp files (C++ compilation units).
  Original Xbox uses XTL (xtl.h) which includes d3d8, dsound etc.
  No xinput.h or xaudio.h - those are Xbox 360 only.
==========================================================================*/
#pragma once

/* XTL is the master Xbox header - includes d3d8.h, dsound.h, etc. */
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <xtl.h>

/* -----------------------------------------------------------------------
   Audio constants
----------------------------------------------------------------------- */
#define AUDIO_SAMPLE_RATE 32000
#define AUDIO_CHANNELS 2
#define AUDIO_BITS 16
#define AUDIO_FRAMES_PER_BLOCK 534
#define AUDIO_BYTES_PER_BLOCK (AUDIO_FRAMES_PER_BLOCK * AUDIO_CHANNELS * (AUDIO_BITS / 8))
#define AUDIO_BUF_BLOCKS 4
#define AUDIO_BUF_BYTES (AUDIO_BUF_BLOCKS * AUDIO_BYTES_PER_BLOCK)

/* -----------------------------------------------------------------------
   Forward declarations for all xbox_*.cpp modules
----------------------------------------------------------------------- */
#ifdef __cplusplus
extern "C" {
#endif

/* D3D renderer */
HRESULT Xbox_D3D_Init(void);
void Xbox_D3D_Shutdown(void);
void Xbox_D3D_BeginDraw(int width, int height, uint8_t **pixels, int *pitch);
void Xbox_D3D_PrepareFrame(void);
void Xbox_D3D_EndDraw(void);
void Xbox_D3D_DrawMenuOverlay(void);
void Xbox_D3D_DrawDimOverlay(void);
int Xbox_D3D_GetDispMode(void);
void Xbox_D3D_SetDispMode(int v);

/* Audio */
HRESULT Xbox_Audio_Init(void);
void Xbox_Audio_Shutdown(void);
void Xbox_Audio_StartThread(void);
void Xbox_Audio_PushFrame(void);
void Xbox_Audio_PushSilence(void);

/* Input - original Xbox uses XInputGetState from xtl.h */
void Xbox_Input_Init(void);
void Xbox_Input_Shutdown(void);
void Xbox_Input_Poll(void);
uint16_t Xbox_Input_GetJoypad(int player);
void Xbox_Input_SuppressUntilRelease(void);

/* Config */
void Xbox_Config_Load(void);
void Xbox_Config_Save(void);

/* Menu */
void Xbox_Menu_Init(void);
void Xbox_Menu_Shutdown(void);
void Xbox_Menu_Update(void);
bool Xbox_Menu_IsOpen(void);
bool Xbox_Menu_IsPaused(void);
bool Xbox_Menu_IsTurbo(void);

/* Platform */
void Xbox_EnsureSaveDir(void);

/* Save states - 4 slots, stored at E:\saves\smw_save0.sav etc */
void Xbox_SaveState(int slot);
void Xbox_LoadState(int slot);

#ifdef __cplusplus
}
#endif