/*
 * xdk_crt_shim.h - CRT shims for Xbox XDK (RXDK)
 * Included automatically via stdbool.h which every TU includes.
 */
#ifndef XDK_CRT_SHIM_H
#define XDK_CRT_SHIM_H

#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include <stddef.h>
#include <malloc.h>
#include <stdlib.h>

/* assert - must come BEFORE types.h includes crtdbg.h and maps assert->_ASSERTE */
#ifndef assert
#  define assert(x) ((void)(x))
#endif

/* __attribute__ - GCC extension, empty on MSVC */
#ifndef __attribute__
#  define __attribute__(x)
#endif

/* alloca */
#ifndef alloca
#  define alloca _alloca
#endif

/* snprintf / vsnprintf */
#ifndef snprintf
static __inline int snprintf(char *buf, size_t n, const char *fmt, ...) {
    int r; va_list ap; va_start(ap, fmt);
    r = _vsnprintf(buf, n, fmt, ap); va_end(ap);
    if (r < 0 || (size_t)r >= n) buf[n-1] = 0;
    return r;
}
#endif
#ifndef vsnprintf
static __inline int vsnprintf(char *buf, size_t n, const char *fmt, va_list ap) {
    int r = _vsnprintf(buf, n, fmt, ap);
    if (r < 0 || (size_t)r >= n) buf[n-1] = 0;
    return r;
}
#endif

/* strdup */
#ifndef strdup
static __inline char *strdup(const char *s) {
    size_t n = strlen(s)+1; char *p = (char*)malloc(n);
    if (p) memcpy(p, s, n); return p;
}
#endif

/* _countof */
#ifndef _countof
#  define _countof(a) (sizeof(a)/sizeof(*(a)))
#endif


/* CLAMP16 macro needed by dsp.c */
#ifndef CLAMP16
#  define CLAMP16(io) { if ((int16_t)(io) != (io)) (io) = ((io) >> 31) ^ 0x7FFF; }
#endif

/* FORCEINLINE */
#ifndef FORCEINLINE
#  define FORCEINLINE __forceinline
#endif

/* uint64 - needed by ppu.c */
#ifndef uint64
typedef unsigned __int64 uint64;
#endif

#endif /* XDK_CRT_SHIM_H */
