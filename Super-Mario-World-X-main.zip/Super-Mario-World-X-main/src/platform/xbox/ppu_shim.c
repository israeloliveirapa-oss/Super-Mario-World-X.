/*
 * ppu_shim.c - Forces ppu_read/write/runLine to have external linkage on MSVC.
 * MSVC C mode: 'inline' = 'static inline' = no external symbol.
 * Fix: redefine 'inline' as nothing before including ppu_xbox.c,
 * so all inline functions become regular extern functions.
 *
 * Use this in the vcxproj INSTEAD of src/snes/ppu.c
 */
#ifdef inline
#undef inline
#endif
#define inline

#include "ppu_xbox.c"
