# Super Mario World X
### Original Xbox Port

A native Original Xbox port of [smw](https://github.com/snesrev/smw), the open-source reimplementation of Super Mario World. Also includes **Super Mario Bros. 1** and **Super Mario Bros. Lost Levels** via the Super Mario All-Stars ROM.

Runs natively on Original Xbox hardware using Direct3D 8, DirectSound and XInput. No emulator required.

---

## Features

### Core Game
- Full Super Mario World playable from start to end
- 60fps gameplay
- 720p output (falls back to 480p if not supported by your TV)
- 4:3 and FILL display modes

### Xbox-Specific Features
- **In-game menu** — Press **L3** (left stick click) to open
- **Save states** — 10 save slots per game, fully integrated with the Xbox Dashboard memory manager. Delete individual save states directly from the dashboard.
- **Dashboard-managed saves** — SRAM and all save states appear in the Xbox Dashboard under Memory → Hard Drive. Users can copy saves to a memory unit or delete them from there.
- **Switch Game** — Switch between Super Mario World, SMB1 and SMBLL from the in-game menu
- **Turbo mode** — Runs the game at 4x speed
- **Pause with dim overlay**
- **Cheats menu** — Add lives, power-ups and coins for all three games
- **Settings menu** — Toggle display mode and sprite limits in-game

---

## Requirements

- Original Xbox console (any revision)
- Hard drive (internal or replacement)
- [RXDK](https://github.com/Team-Resurgent/RXDK) — Xbox Development Kit for MSVC
- Visual Studio 2019 or newer
- A **USA region** copy of the Super Mario World ROM (`smw.sfc`)
- Python 3.x (for asset extraction)

---

## Building

### Step 1 — Install Python and dependencies

1. Download and install [Python 3](https://www.python.org/downloads/) — check **"Add to PATH"** during install
2. Open a command prompt and run:
```
python -m pip install --upgrade pip pillow pyyaml
```

### Step 2 — Extract SMW assets

1. Place your USA ROM named `smw.sfc` in the root of the repository
2. Double-click `extract_assets.bat` in the root directory
3. This creates `smw_assets.dat` in the same folder — keep this file

### Step 3 — Extract SMB1 and SMBLL assets (optional)

1. Install zstandard: `pip install zstandard`
2. Place your USA Super Mario All-Stars ROM named `smas.sfc` in the `other/` folder (not the `+ Mario World` version)
3. Run `extract.py` in the `other/` folder — this produces `smb1.sfc` and `smbll.sfc`
4. Place both files into `src/Media/` before building

### Step 4 — Install RXDK

1. Download [RXDK](https://github.com/Team-Resurgent/RXDK) and follow its installation instructions
2. Ensure the `RXDK_LIBS` environment variable is set (the RXDK installer does this automatically)

### Step 5 — Open and build the project

1. Open `src/smw_xbox.vcxproj` in Visual Studio 2019 or newer
2. Select **Release | Win32** configuration
3. Place `smw_assets.dat` into the `src/Media/` folder
4. Press **F7** (Build Solution)

### Step 6 — Build output

After a successful build the post-build script automatically:
- Patches the XBE subsystem flag
- Builds the title image and save image into `.xbx` format
- Assembles the build folder
- Packs an XISO

```
src/Release/
    smw_xbox.xbe             Raw XBE (intermediate)
    Build/
        smw_xbox/
            default.xbe      ← Copy this to your Xbox
            Media/
                smw_assets.dat
                smb1.sfc     (if present)
                smbll.sfc    (if present)
    XISO/
        smw_xbox.iso         ← Burn or mount this
```

The build summary printed at the end shows:
```
Title:    Super Mario World X
Title ID: 0x54520001
TDATA:    E:\TDATA\54520001
UDATA:    E:\UDATA\54520001
Build:    ...\Release\Build\smw_xbox
ISO:      ...\Release\XISO\smw_xbox.iso
```

---

## Installation

### Option A — Copy files to Xbox hard drive (FTP)
1. Connect to your Xbox via FTP
2. Copy the entire `Build/smw_xbox/` folder to your Xbox (e.g. `E:\Games\SuperMarioWorldX\`)
3. Launch `default.xbe` from your dashboard

### Option B — Burn/mount ISO
1. Use the generated `XISO/smw_xbox.iso`
2. Burn to DVD-R or mount via a disc emulator

---

## File Layout on Xbox

```
E:\Games\SuperMarioWorldX\
    default.xbe
    Media\
        smw_assets.dat
        smb1.sfc     (optional)
        smbll.sfc    (optional)
```

The game will always look for assets in `D:\Media\` — on Xbox, `D:` always points to the launch directory regardless of which dashboard you use.

`titleimage.png` and `saveimage.png` are already included in the `src/` folder and are embedded into the XBE automatically during the build.

---

## Save Data

All saves are stored in **UDATA** — the Xbox Dashboard's user data region. This means saves appear in the dashboard memory manager and can be managed (copied to memory unit, deleted) without launching the game.

| Dashboard entry | Contents |
|---|---|
| `SMW - Game Save` | SRAM + config |
| `SMW - State 1` | Save state slot 1 |
| ... | ... |
| `SMW - State 10` | Save state slot 10 |
| `SMB1 - Game Save` | SRAM + config |
| `SMB1 - State 1` … `SMB1 - State 10` | Save state slots |
| `SMBLL - Game Save` | SRAM + config |
| `SMBLL - State 1` … `SMBLL - State 10` | Save state slots |

Save state folders are only created when you first save to that slot — unused slots create no folders.

---

## Controls

| Xbox Button | SNES Button | Action |
|---|---|---|
| A | B | Jump |
| B | A | Spin jump |
| X | Y | Run / pick up item |
| Y | X | Look up / accelerate |
| Left Trigger | L | Scroll left |
| Right Trigger | R | Scroll right |
| D-Pad | D-Pad | Movement |
| Start | Start | Pause |
| Back | Select | Drop reserve item |
| L3 (left stick click) | — | Open Xbox menu |

White and Black buttons are unassigned.

### Xbox Menu (L3)

| Menu item | Description |
|---|---|
| SWITCH GAME | Switch between SMW, SMB1 and SMBLL |
| CHEATS | Lives, power-ups, coins |
| SETTINGS | Display mode, sprite limits |
| SAVE STATE | Save to one of 10 slots |
| LOAD STATE | Load from a slot (shows error if slot is empty) |
| TURBO MODE | Toggle 4x speed |
| PAUSE GAME | Pause with dim overlay |
| RESET GAME | Reset to title screen |
| EXIT GAME | Exit to Xbox dashboard |
| CLOSE | Close menu and resume |

---

## Project Structure

```
src/
    platform/
        xbox/               ← All Xbox-specific code (never modify base game files)
            xbox_main.cpp       Entry point, game loop, drive mounting
            xbox_d3d.cpp        Direct3D 8 renderer
            xbox_audio.cpp      DirectSound audio
            xbox_input.cpp      XInput controller handling
            xbox_menu.cpp       In-game menu, cheats, settings, save/load
            xbox_menu.h         Menu declarations
            xbox_savegame.cpp   UDATA save path resolution
            xbox_platform.h     Master Xbox header
            xbox_fixes.h        Compiler fixes
            xbox_config.cpp     Config/INI save and load
            alloca_probe.cpp    XDK linker stubs
            smw_rtl_xbox.c      RTL with HDMA timing fix
            smw_spc_player_xbox.c  SPC player fix
            snes_other_xbox.c   snes_other fix
            dma_xbox.c          DMA bool normalisation fix
            ppu_xbox.c          PPU XRGB8888 output
            ppu_shim.c          PPU inline linkage fix
            config_xbox.c       Replaces config.c (no SDL)
            xdk_crt_shim.h      CRT shims
            SDL.h               SDL stub
            SDL_keycode.h       SDL keycode stub
            stdbool.h           C99 bool for MSVC
            stdint.h            C99 fixed-width integers for MSVC
            intrin.h            Intrinsics stub
    Media/                  ← Place smw_assets.dat here before building
    smw_xbox.vcxproj        Visual Studio project file
    smw_xbox.vcxproj.filters
```

The base game source files are **never modified**. All Xbox-specific code lives entirely in `platform/xbox/`.

---

## License

The smw reimplementation is licensed under the MIT license. See `LICENSE.txt` for details.

The Xbox port code in `src/platform/xbox/` follows the same license.
